@echo off
REM Run the replication pipeline (Windows)
REM Usage: double-click run.bat or run from command prompt

cd /d "%~dp0"

echo Checking Python...
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ERROR: Python not found. Install Python 3.8+ from https://www.python.org
    echo Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)

python --version

echo Installing dependencies...
python -m pip install -q -r requirements.txt

echo.
echo Running pipeline...
python run_pipeline.py

echo.
echo Done.
pause

echo.
echo Running supplementary permutation tests (Tables 6-7)...
python3 supplementary_tests.py
