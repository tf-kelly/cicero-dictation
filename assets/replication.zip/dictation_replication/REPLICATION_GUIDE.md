
# Replication guide: *haec scripsi, seu dictavi*: Dictation and Writing in Cicero's Letters to Atticus

The Python code used to implement the statistical pipeline described in this guide was developed with assistance from two large language models: ChatGPT (OpenAI: GPT-4o and GPT-5 models, accessed via chat.openai.com between August 2025 and March 2026) and Claude (Anthropic: Opus 4.6, accessed via claude.ai between March 2026 and April 2026). All code was reviewed, executed, and tested locally.  The author takes responsibility for the correctness of the code.


---

## Please follow these instructions to generate the results in the paper (requires Python 3.10+ and the packages listed in `requirements.txt`)

    pip install -r requirements.txt
    bash run.sh        # macOS/Linux
    run.bat            # Windows

This runs `run_pipeline.py` end-to-end (well under a minute on a laptop),
regenerates `figure1.pdf`, and prints the statistics reported in
Sections III–IV of the paper. For the supplementary permutation tests
(Appendix A.3, Tables 6–7), run `python3 supplementary_tests.py`
separately — see Section 16 below.

## 1. Corpus 

### Source data

| File                                               | Contents                                                                                                                                              |
| -------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| `data/units.csv`                                   | All letters *ad Atticum*, using Vulgate numbering: `unit_id`, `text`, `label` (Auto/Dict/Rest). 433 rows. Salutations included in text.               |
| `data/allunits.csv`                                | As above, but includes the split halves of 11.24 and 13.28 (as `11.24a`, `11.24d`, `13.28a`, `13.28d`), and excludes 11.24 or 13.28 as whole letters. |
| `data/cicero_ad_fam_from_cicero.csv`               | *ad Familiares* letters from Cicero. Used for enrichment Path A                                                                                       |
| `data/cicero_ad_quintum_fratrem.csv`               | *ad Quintum Fratrem* letters. Used for Enrichment Path. Two letters (Qfr 2.2, 3.3) are labelled Dict on the basis of internally derived metadata      |
| `data/cicero_atticus_unit_id_date_with_sb__1_.csv` | Shackleton Bailey dating for letters *Ad Atticum*: `unit_id`, `date`, `sb_number`.                                                                    |

### Text preprocessing

Before the analysis, salutations were removed from the start of each letter. The following patterns were removed
- Att: `CICERO ATTICO salutem` (and variants with `Scr.` dating prefix)
- Fam: `S.D.` formulae with addressee names
- Qfr: `FRATRI SALUTEM` / `S.D.` formulae

### Letter counts

67 letters were identifiable as dictated or autograph. Two letters (11.24 and 13.28) begin as dictated and end in Cicero's own hand; because the unit of analysis is the full letter, these are excluded. 

After excluding very short letters (fewer than 5 sentences), 65 labelled letters remain: **46 Auto + 19 Dict**.

The `units.csv` file contains these labels. The syntax analysis (`scores_ge5.csv`) excludes letters with fewer than 5 sentences.
### Split letters in `allunits.csv`

The file `allunits.csv` contains split halves of 11.24 and 13.28 for reference, but **the pipeline does not use the split letters**. The principal rationale was that the main syntactic features used to sort the letters (LP and SD) are features that operate at the level of the letter itself, so the inclusion of these letters could adversely affect the results.

### REST for enrichment

For enrichment tests (Path A, Section 3.4), the REST group comprised the **368 unlabelled letters *ad Atticum***.

As a robustness check (footnote 60 in the paper), the enrichment was also run with an expanded REST group (496 letters), adding letters from:
- *ad Quintum Fratrem* (25 letters, excluding Qfr 2.2 and 3.3 which are Dict)
- *ad Familiares* recipients among Cicero's close circle: Terentia, Tiro, M. Marius, Varro

All nine features were distributed in the predicted direction at the 15% threshold in both the Atticus-only and expanded analyses.

Syntax scores for the letters *ad familiares* and *ad Quintum fratrem* `data/fam_qfr_syntax_scores.csv`.

---

## 2. Feature exploration: lexical, morphological, pragmatic)

### Feature definitions

All features are computed on the salutation-stripped text. Token counts use the regex `\b[a-zA-Z\u00C0-\u024F]+\b` (Latin alphabetic words including macrons).

**Continuous features (pooled rates):**

| Feature | Definition | Unit | Direction |
|---|---|---|---|
| velim | Count of *velim* | ‰ (per 1000 tokens) | Dict > Auto |
| exclamations | Count of *mehercule*, *hercle*, *obsecro*, exclamatory *o* | ‰ | Dict > Auto |
| nec_ratio | nec / (nec + neque) | ratio [0,1] | Dict > Auto |
| ac_ratio | (ac + atque) / (ac + atque + et + -que) | ratio [0,1] | Auto > Dict |
| si_et | Count of sentence-initial *et* (after `.!?;` or at text start) | ‰ | Dict > Auto |

For ac_ratio, the denominator includes all coordinating conjunctions. The enclitic *-que* is counted by matching words ending in *-que* after excluding a fixed set (neque, quoque, usque, itaque, atque, etc. — see pipeline code for the full list).

**Binary features (presence/absence per letter):**

| Feature              | Definition                                                        | Forms matched                                                                                                                                                                                                                    |
| -------------------- | ----------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| future imperatives   | Any future imperative form present                                | scito, curato, facito, memento, habeto, videto, mittito, caveto, dicito                                                                                                                                                          |
| long perfects        | Any unsyncopated 1st-conjugation perfect present                  | Regex patterns for -avisse, -avissem, -averunt, -avisti, -averat, etc. 2nd-conj stems in -av- (caveo, faveo, paveo, laveo) excluded. Non-1st-conjugation stems (petiv-, quaesiv-, sciv-, nov-, consuev-) removed from detection. |
| ego autem            | Bigram *ego autem* present                                        | Bigram match                                                                                                                                                                                                    |
| adversative quamquam | Post-punctuation *quamquam* used adversatively (not concessively) | *quamquam* after `.!?;`, with manual concessive exceptions listed in `PP_CONC` dict (5 letters)                                                                                                                                  |

### Statistical test for continuous features

Pooled, letter-level bootstrap test (2-sided, 2000 iterations):
1. Pool all letters from both groups.
2. For each iteration, resample with replacement, splitting into groups of original size.
3. Compute the pooled rate for each resampled group.
4. The observed difference is compared to the null distribution of differences.
5. p = proportion of null differences ≥ |observed| in absolute value.

### Statistical test for binary features

Fisher's exact test (two-sided) on the 2×2 contingency table of presence/absence × label.

---

## 3. Feature exploration: syntax

### Parsing

Sentence segmentation and dependency parsing were performed using the Stanza Latin UD parser. The root of each sentence (the syntactic head of the dependency tree) was taken as the main predicate.

For the labelled groups, the roots were manually corrected, with 24% of sentences requiring correction, without significant difference to the resultant AUC (measure of separation between the letters). The parser's sentence divisions were retained except where the parser made erroneous splits between sentences (e.g. after 'Cn.').

### Syntactic measures

For each letter, the position of the root in each sentence was recorded as a fraction of sentence length (0 = first token, 1 = last token).

Two letter-level summary measures:
- proportion of sentences where the root falls in the last third
- standard deviation of root position across sentences

Both were residualised against letter length (number of sentences) using linear regression on the labelled letters, in order to control for the mechanical relationship between letter length and these measures.

The residualised scores are given by the abbreviations LP and SD respectively.


`data/scores_ge5.csv` contains one row per letter *ad Atticum* with ≥5 sentences. The raw and length-residualised scores are included

- `prop_late_last_third_resid` = LP
- `sd_root_pos_rel_resid` = SD

### AUC and significance

Separation between Auto and Dict on LP was quantified by ROC AUC (Mann-Whitney U statistic, scaled to [0,1]).

For LP, AUC = 0.763, MW p = 0.0009. Also: SD AUC = 0.819, p < 0.001.

---

## 4. Path A: Enrichment

### Posterior computation

Each REST letter is assigned P(Dict | pl_resid) under a two-component Gaussian mixture model.

Parameters (from `data/enrichment_model_params.csv`):
- Auto: μ = 0.000, σ = 0.079
- Dict: μ = −0.074, σ = 0.093

The prior (π₀ = 0.30) affects absolute posterior values but, importantly, not the rank ordering of letters (since the prior is constant across all letters). The ranking, and therefore the composition of the enriched groups, is prior-invariant. The prior matters only for the attenuation correction, which is calculated after an estimate for the prior has been independently derived (§7).

### Enrichment groups

REST letters (*ad Atticum* -- 368) are sorted by P(Dict|LP). The most Dict-like letters form eD; the most Auto-like form eA.

At threshold X%:
- eD = labelled Dict + top X% of REST by posterior
- eA = labelled Auto + bottom X% of REST by posterior

### Feature screening (Lab+5%)

At Lab+5% (~25 letters per tail added to the labelled set, ~50 total), ego (nom.) and qq_share were dropped because they did not maintain the expected direction. Nine features were retained.

### 'Doughnut' test

In order to ensure full independence from the Lab+5% screening, features were tested on REST letters BETWEEN the 5th percentile and the nth percentile at each tail — i.e., excluding the most extreme 5% that were used for screening.

At threshold T%:
- doughnut_eD = REST letters with posterior rank between (100−T)% and 95%
- doughnut_eA = REST letters with posterior rank between 5% and T%

Direction was assessed for each of 9 features. The overall direction count was tested by the binomial probability of observing ≥k/9 correct under H₀ of random direction (p = 0.5 each, independent).

Result: direction count varies by threshold: 8/9 at 10% (p = 0.020), 9/9 at 15% (p = 0.002), 7/9 at 20% (p = 0.090), 9/9 at 25% (p = 0.002).

---

## 5. Path B: Augmentation with binary markers

The four binary Auto markers (future imperatives, long perfects, ego autem, adversative quamquam) have near-perfect separation in labelled data (all present in Auto, absent in Dict) but are uncorrelated with LP in REST (|ρ| ≤ 0.065).

Test: For each marker, take the REST letters where the marker is present. Add them to Auto. Recompute the AUC of LP for Auto+marked vs Dict. Compare to the AUC obtained by adding a random sample of REST letters of the same size.

The marker-augmented AUC preserves the labelled separation better than almost all random samples of equivalent size.

---

## 6. Base rate estimation

### Primary method: Joint maximum likelihood

The pipeline estimates the proportion, π, of Dict-like letters by fitting a mixture model to the REST letters *ad Atticum*, using four features (*velim* rate, exclamations rate, sentence-initial *et* rate, presence of any Auto marker) with distributions estimated from the labelled groups. Laplace smoothing is applied to marker rates.

Result: **π = 0.361, 95% CI [0.294, 0.434]**

By weighting the mean of the same procedure, but enacted in chronological windows, the model gives π = 0.305. 

### Chronologically stable marker rate

Long perfects and *ego autem* show no significant chronological trend (p = 0.99, p = 0.05 respectively). Their rate in labelled Auto (21.7% = 10/46) vs Dict (0%) gives:

π = 1 − (REST marker rate / Auto marker rate) = 1 − (12.8% / 21.7%) ≈ 0.41

The confidence interval for this figure is very wide, due to the sparsity of these features and the small sample siz.e

### Summary

Likely range: **π ∈ [0.25, 0.40]; best estimate π ≈ 0.30–0.36**.

---

## 7. Enrichment with correction (attenuation correction)

### Attenuation factor λ

At each threshold T%, the enriched groups eD and eA contain a mixture of Auto and Dict letters. Define:
- π_D = mean P(Dict|LP) in eD
- π_A = 1 − mean P(Dict|LP) in eA (i.e., mean P(Auto) in eA)
- λ = π_D + π_A − 1

λ represents the "purity" of the enriched groups. When groups are perfectly pure, λ = 1; when groups are equal mixtures, λ = 0.

The observed difference between eD and eA for any feature is attenuated by factor λ relative to the true Auto−Dict difference. The corrected test statistic is:

```
z_corrected = (observed_delta / λ) / SE_null
```

where SE_null is the standard deviation of the null distribution from a bootstrap permutation test.

### λ values at π₀ = 0.30

| Threshold | λ |
|---|---|
| 5% | 0.903 |
| 10% | 0.837 |
| 15% | 0.768 |
| 20% | 0.710 |
| 25% | 0.652 |

### p-value computation

For each continuous feature at each threshold:
1. Form eD and eA from REST (excluding labelled letters — REST-only tails).
2. Compute observed delta = feature(eD) − feature(eA).
3. Pool all letters in eD ∪ eA. Bootstrap resample (2000 iterations), splitting into groups of size |eD| and |eA|. Compute delta for each resample → null distribution.
4. SE = standard deviation of null deltas.
5. p_corrected = 2 × (1 − Φ(|observed_delta / λ| / SE)), where Φ is the standard normal CDF.

For binary features: Fisher's exact test on the 2×2 table (no attenuation correction applied to binary features, since Fisher's test operates on counts, not effect sizes).

If the feature direction is wrong compared with the hypothesis, the cell shows ✗ and the feature is not tested for significance.

---

## 8. Multiple testing correction

Benjamini-Hochberg at q = 0.05, applied to the doughnut test p-values (§4).

The denominator is n = 11: the 9 retained features, plus 2 features (ego nominative rate, qq_share ratio) that were dropped at Lab+5% screening and are included as p = 1.0.

 Additional features that were dropped pre-screening are NOT included in the BH denominator, since the doughnut test applies to letters not used for the initial feature exploration, and is instead a test of the hypothesis generated by the results of that exploration. 

---

## 9. Robustness: SD sorting

The entire enrichment procedure (§4–§8) was rerun using SD instead of LP as the sorting criterion.

SD shares approximately 32% of variance with pl_resid. At the 15% threshold, the Jaccard overlap between the tails sorted by the two criteria is 0.39 (Dict-leaning) and 0.21 (Auto-leaning).

---

## 10. Composite ranking (D)

The composite ranking D combines all features into a single dictation-probability score per letter. It is reported as D^C (percentile, 1 = most Dict-like, 100 = most Auto-like).

Definition is in `data/letter_d_scores.csv`:
- `D_score`: z-scored composite (positive = more Dict-like)
- `D_percentile`: percentile rank (1 = most Dict-like, 100 = most Auto-like)
- Individual feature values: `pl_resid`, `sd_resid`, `velim_rate`, `excl_rate`, `si_et_rate`, `nec_ratio`, `ac_ratio`
- `has_marker`, `marker_types`: binary markers present

AUC of D on labelled groups: 0.862 (MW p = 0.000005).
AUC on explicit-only labels (4 Auto, 9 Dict): 0.750 (p = 0.199).
AUC with eye-trouble letters removed (46 Auto, 16 Dict): 0.853 (p < 0.0001).

---

## 11. Chronological information

Dates are from Shackleton Bailey's ordering (`data/cicero_atticus_unit_id_date_with_sb__1_.csv`).


- Auto mean date: ~59 BCE
- Dict mean date: ~48 BCE
- Gap: ~11 years. This is a fact of the labelled data and cannot be addressed directly. 

Syntax correlates with date in REST; however, to avoid obscuring a real signal, the syntactic variable was not controlled for chronology direclty. The chronology confound is addressed separately in Section 4.2 of the paper. 

- LP × year: ρ = −0.117, p = 0.038
- SD × year: ρ = −0.217, p < 0.001

---

## 12. Internal labelling concordance

The same variable appears under different names in different files:

| Paper name | `scores_ge5.csv`             | `combined_corpus_features.csv` | `fam_qfr_syntax_scores.csv`  |
| ---------- | ---------------------------- | ------------------------------ | ---------------------------- |
| LP         | `prop_late_last_third_resid` | `pl_resid`                     | `prop_late_last_third_resid` |
| SD         | `sd_root_pos_rel_resid`      | (not present)                  | `sd_root_pos_rel_resid`      |


---

## 13. Summary of files

| File                                          | Rows   | Key columns                                       | Used in                                                                   |
| --------------------------------------------- | ------ | ------------------------------------------------- | ------------------------------------------------------------------------- |
| `units.csv`                                   | 433    | unit_id, text, label                              | Text source for *ad Atticum* features                                     |
| `allunits.csv`                                | 435+   | unit_id, text, label                              | Split letter halves (11.24a/d, 13.28a/d). This file is for reference only |
| `scores_ge5.csv`                              | ~400   | unit_id, label, pl_resid, sd_resid, etc.          | Syntax scores (LP and SD); enrichment sorting                             |
| `combined_corpus_features.csv`                | ~570   | uid, corpus, label, tokens, pl_resid, velim, etc. | Pre-computed features, 3-corpus (Att primary; Fam/Qfr for robustness)                                           |
| `enrichment_model_params.csv`                 | 10     | parameter, value                                  | Gaussian mixture parameters for posterior                                 |
| `cicero_atticus_unit_id_date_with_sb__1_.csv` | ~426   | unit_id, date, sb_number                          | Inclusion of number for dating                                            |
| `cicero_ad_fam_from_cicero.csv`               | varies | unit_id, text                                     | Text for letters *ad familiares*                                          |
| `cicero_ad_quintum_fratrem.csv`               | varies | unit_id, text                                     | Text for letters *ad Quintum fratrem*                                     |
| `fam_qfr_syntax_scores.csv`                   | varies | uid, corpus, sd_resid, pl_resid                   | Syntax scores for letters *ad familiares* and *ad Quintum fratrem*        |
| `letter_d_scores.csv`                         | 433    | uid, label, D_score, D_percentile, features       | Composite ranking D                                                       |
| `letter_rankings_v2.csv`                      | varies | uid, label, ranking data                          | Letter rankings (supplementary)                                           |

---

## 14. Automatic replication

The pipeline (`run_pipeline.py`) replicates the following sections of the paper:
- Figure 1 (KDE density plot of LP for Auto, Dict, and Rest groups; saved as `figure1.pdf`)
- §2 labelled feature comparison (feature rates and p-values)
- §3 syntax separation (AUC, MW p)
- Lab+5% screening
- §4 doughnut test (Table 1)
- Path B augmentation
- §6 base rate estimation (ML model, marker rate)
- §7 corrected tails (Table 4)
- §8 BH correction (Table 5)
- §9 SD robustness
- §10 composite D ranking and AUC
- §4.2 AUCs for subset analysis (explicitly labelled letters only and letters without eye trouble)
- §4.3 matched pairs and outlier D^C scores
- Chronological correlations
---

## 15. Notes

**Note on `enrichment_model_params.csv`**: This file records `prior_dict = 0.3` and `n_labelled_dict = 21 (Att 19 + Qfr 2)`. The two Dict letters *ad Quintum fratrem* contribute to the Gaussian parameter estimation but are not part of the labelled set of letters *ad Atticum* used for AUC calculations. 

---

## 16. Supplementary permutation tests (Tables 6–7)

The file `supplementary_tests.py` replicates the permutation tests reported in Appendix A.2 of the paper (Tables 6 and 7).

**Table 6** (direction-count permutation test): For each of 2,000 permutations, LP scores are randomly shuffled among REST letters, the doughnut tails are reconstituted, and the number of features in the predicted direction is counted. The reported *p*-value is the proportion of permutations yielding at least the observed direction count.

**Table 7** (signed *z*-score sum permutation test): As above, but the test statistic is the sum of signed *z*-scores across all 9 features (positive when the feature is in the predicted direction, weighted by effect magnitude). This test is more sensitive than the binary direction count.

### Running

```bash
python3 supplementary_tests.py
```

Requires the same dependencies as `run_pipeline.py` (numpy, scipy). Output includes:
- **Tests 2 & 3**: Permutation omnibus tests producing the *p*-values in Tables 6 and 7.

Note: permutation *p*-values have Monte Carlo variance (±0.005 at 2,000 iterations). Results may differ slightly across runs due to random seed.
