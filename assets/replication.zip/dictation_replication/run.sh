#!/bin/bash
# Run the replication pipeline (Mac/Linux)
# Usage: ./run.sh

set -e
cd "$(dirname "$0")"

echo "Checking Python..."
if command -v python3 &>/dev/null; then
    PY=python3
elif command -v python &>/dev/null; then
    PY=python
else
    echo "ERROR: Python not found. Install Python 3.8+ from https://www.python.org"
    exit 1
fi

echo "Using: $($PY --version)"

echo "Installing dependencies..."
$PY -m pip install -q -r requirements.txt

echo ""
echo "Running pipeline..."
$PY run_pipeline.py

echo ""
echo "Running supplementary permutation tests (Tables 6-7)..."
python3 supplementary_tests.py
