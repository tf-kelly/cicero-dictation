#!/usr/bin/env python3
"""
Supplementary statistical tests:
  1. Power simulation: expected direction-count at each doughnut threshold
  2. Permutation omnibus test: p-value for observing ≥k/9 correct directions
"""

# ── Import everything from the pipeline ──────────────────────────────────

import csv, re, numpy as np
from scipy import stats
from scipy.stats import norm, spearmanr, mannwhitneyu
from pathlib import Path

SEED = 42; N_BOOT = 2000; PI_0 = 0.30
DATA_DIR = Path(__file__).parent / "data"

# ── Paste in data loading and helpers from pipeline ──────────────────────
# (We re-run the pipeline internals rather than importing, to keep this
#  self-contained and auditable.)

letters = {}
with open(DATA_DIR / 'units.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        letters[row['unit_id']] = {'text': row['text'], 'label': row['label']}

scores_pl = {}; scores_sd = {}
with open(DATA_DIR / 'scores_ge5.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        scores_pl[row['unit_id']] = float(row['prop_late_last_third_resid'])
        scores_sd[row['unit_id']] = float(row['sd_root_pos_rel_resid'])

combined = {}
with open(DATA_DIR / 'combined_corpus_features.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        combined[row['uid']] = row

fam_text = {}
with open(DATA_DIR / 'cicero_ad_fam_from_cicero.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        fam_text[row['unit_id']] = row['text']
qfr_text = {}
with open(DATA_DIR / 'cicero_ad_quintum_fratrem.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        qfr_text[row['unit_id']] = row['text']

# ── Helpers (copied from pipeline) ───────────────────────────────────────

def strip_sal_att(t):
    return re.sub(r'^(?:Scr\..*?\.\s*)?CICERO\s+ATTICO\s+salutem\b','',t,flags=re.I).strip()
def strip_sal_fam(t):
    t = re.sub(r'^Scr\.\s+[^.]+\.\s*', '', t).strip()
    return re.sub(r'^[A-Z\s.]+S\.\s*D\.\s*', '', t).strip()
def strip_sal_qfr(t):
    return re.sub(r'^.*?(?:FRATRI\s+SALUTEM|S\.\s*D\.)', '', t, flags=re.I).strip()
def tokenize(t):
    return re.findall(r'\b[a-zA-Z\u00C0-\u024F]+\b', t.lower())

OATH_PAT = [r'\bme\s*hercule\b', r'\bhercle\b', r'\bobsecro\b']

def count_o(text, clean):
    n = 0
    for m in re.finditer(r'\bo\b', clean):
        after = clean[m.end():m.end()+20]
        if re.match(r'\s*[\(\)\\=/]', after): continue
        n += 1
    return n

FI_PAT = [r'\bscito\b',r'\bfacito\b',r'\bmemento\b',r'\bhabeto\b',
           r'\bvideto\b',r'\bmittito\b',r'\bcurato\b',r'\bcaveto\b',r'\bdicito\b']
LP_PAT = [r'\b\w+avisse\b',r'\b\w+aviss(?:em|et|ent|es)\b',r'\b\w+averunt\b',
           r'\b\w+avisti(?:s)?\b',r'\b\w+aver(?:at|am|as|ant|amus)\b',
           r'\b\w+aver(?:it|im|is|int|o|imus)\b']
LP_EXCLUDE_STEMS = {'cav', 'fav', 'pav', 'lav'}

def has_long_perf(text):
    for pat in LP_PAT:
        for m in re.finditer(pat, text, re.I):
            word = m.group().lower()
            stem_m = re.match(r'(\w+?)av', word)
            if stem_m and stem_m.group(1) in LP_EXCLUDE_STEMS: continue
            return True
    return False

QUE_EXCL = {'neque','quoque','usque','quaque','undique','ubique','denique',
    'itaque','atque','namque','quisque','quemque','quamque','quibusque',
    'cuiusque','cuique','quidque','quaeque','quodque','uterque','utrique',
    'utrumque','utriusque','utroque','utramque','utraque','cumque',
    'quicumque','quaecumque','quodcumque','quocumque','quacumque',
    'quemcumque','quamcumque','quibuscumque','cuicumque','ubicumque',
    'undecumque','quandocumque','qualiscumque','qualecumque','qualicumque',
    'qualescumque','quantulacumque','quantuscumque','utique','aeque',
    'quinque','plerumque','plerique','pleraque','quousque'}

# Adversative quamquam: manually reviewed lookup (see data/quamquam_adv_reviewed.csv)
QQ_ADV_REVIEWED = {}
with open(DATA_DIR / 'quamquam_adv_reviewed.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        QQ_ADV_REVIEWED[row['letter_id']] = int(row['adv_count'])

def count_qq_adv(uid, text):
    """Return adversative quamquam count from manual review (Att letters).
    Falls back to post-punctuation heuristic for non-Att letters."""
    if uid in QQ_ADV_REVIEWED:
        return QQ_ADV_REVIEWED[uid]
    # Fallback for Fam/Qfr: original post-punctuation heuristic
    n = 0
    for m in re.finditer(r'\bquamquam\b', text, re.I):
        before = text[max(0, m.start()-3):m.start()].strip()
        if not re.search(r'[.!?;]$', before): continue
        n += 1
    return n

def count_si_et(text, clean):
    n = len(re.findall(r'[.!?;]\s+[Ee]t\b', clean))
    if re.match(r'\s*[Ee]t\b', clean): n += 1
    return n

def featurize(uid, text_raw, clean, n_tokens):
    nec = len(re.findall(r'\bnec\b', clean, re.I))
    neque = len(re.findall(r'\bneque\b', clean, re.I))
    atque_n = len(re.findall(r'\batque\b', clean, re.I))
    ac_n = len(re.findall(r'\bac\b', clean, re.I))
    et_n = len(re.findall(r'\bet\b', clean, re.I))
    que_w = [w for w in re.findall(r'\b[a-zA-Z\u00C0-\u024F]+que\b', clean.lower()) if w not in QUE_EXCL]
    coord = et_n + atque_n + ac_n + len(que_w)
    return {
        'tokens': n_tokens,
        'velim_n': len(re.findall(r'\bvelim\b', text_raw, re.I)),
        'excl_n': sum(len(re.findall(p, text_raw, re.I)) for p in OATH_PAT) + count_o(text_raw, clean),
        'nec_n': nec, 'neque_n': neque,
        'ac_atque_n': ac_n + atque_n, 'coord_n': coord,
        'si_et_n': count_si_et(text_raw, clean),
        'fi_p': 1 if sum(len(re.findall(p, text_raw, re.I)) for p in FI_PAT) > 0 else 0,
        'lp_p': 1 if has_long_perf(text_raw) else 0,
        'ea_p': 1 if len(re.findall(r'\bego\s+autem\b', text_raw, re.I)) > 0 else 0,
        'qq_adv_p': 1 if count_qq_adv(uid, text_raw) > 0 else 0,
    }

# ── Build corpus ──────────────────────────────────────────────────────────

all_letters = []
for uid, info in letters.items():
    if uid not in scores_pl: continue
    text_raw = info['text']
    clean = strip_sal_att(text_raw)
    toks = tokenize(clean)
    n = len(toks)
    if n < 20: continue
    feat = featurize(uid, text_raw, clean, n)
    feat.update({'uid': uid, 'corpus': 'Att', 'label': info['label'],
                 'pl_resid': scores_pl[uid], 'sd_resid': scores_sd[uid]})
    all_letters.append(feat)

for uid_full, row in combined.items():
    corpus = row['corpus']
    if corpus == 'Att': continue
    label = row['label']
    short = uid_full.replace('fam_','').replace('qfr_','')
    if corpus == 'Fam' and short in fam_text:
        text_raw = fam_text[short]; clean = strip_sal_fam(text_raw)
    elif corpus == 'Qfr' and short in qfr_text:
        text_raw = qfr_text[short]; clean = strip_sal_qfr(text_raw)
    else: continue
    toks = tokenize(clean)
    n = len(toks)
    if n < 20: continue
    feat = featurize(short, text_raw, clean, n)
    feat.update({'uid': uid_full, 'corpus': corpus, 'label': label,
                 'pl_resid': float(row['pl_resid']),
                 'sd_resid': float(combined[uid_full].get('pl_resid', '0'))})
    all_letters.append(feat)

fq_sd = {}
try:
    with open(DATA_DIR / 'fam_qfr_syntax_scores.csv', newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            fq_sd[row['uid']] = float(row['sd_root_pos_rel_resid'])
except: pass
for r in all_letters:
    if r['corpus'] != 'Att' and r['uid'] in fq_sd:
        r['sd_resid'] = fq_sd[r['uid']]

A = [r for r in all_letters if r['label']=='Auto']
D_att = [r for r in all_letters if r['label']=='Dict' and r['corpus']=='Att']
D_qfr = [r for r in all_letters if r['label']=='Dict' and r['corpus']=='Qfr']
R = [r for r in all_letters if r['label']=='Rest']
R_att = [r for r in R if r['corpus']=='Att']

# ── Feature functions ─────────────────────────────────────────────────────

def rate_k(g, key):
    t = sum(r[key] for r in g); n = sum(r['tokens'] for r in g)
    return t/n*1000 if n>0 else 0

def nec_ratio(g):
    n = sum(r['nec_n'] for r in g); q = sum(r['neque_n'] for r in g)
    return n/(n+q) if (n+q)>0 else np.nan

def lit_share(g):
    l = sum(r['ac_atque_n'] for r in g); t = sum(r['coord_n'] for r in g)
    return l/t if t>0 else np.nan

CONT = [
    ('velim',        lambda g: rate_k(g,'velim_n'), '+'),
    ('exclamations', lambda g: rate_k(g,'excl_n'),  '+'),
    ('nec_ratio',    nec_ratio,                      '+'),
    ('ac_ratio',     lit_share,                      '-'),
    ('si_et',        lambda g: rate_k(g,'si_et_n'), '+'),
]
BIN = [
    ('fut imp',   'fi_p',     'A>D'),
    ('long perf', 'lp_p',     'A>D'),
    ('ego autem', 'ea_p',     'A>D'),
    ('qq_adv',    'qq_adv_p', 'A>D'),
]

def dir_c(delta, exp):
    if delta is None: return False
    return ('+' if delta>0 else '-') == exp

def dir_b(ra, rd, exp):
    return ra > rd if exp=='A>D' else rd > ra

def get_doughnut(R_pool, sort_key, th, pi=PI_0):
    mu_a = np.mean([r[sort_key] for r in A])
    sd_a = np.std([r[sort_key] for r in A], ddof=1)
    mu_d = np.mean([r[sort_key] for r in D_att])
    sd_d = np.std([r[sort_key] for r in D_att], ddof=1)
    def post(x):
        la=norm.pdf(x,mu_a,sd_a); ld=norm.pdf(x,mu_d,sd_d)
        return (ld*pi)/(ld*pi+la*(1-pi))
    PA = np.array([post(r[sort_key]) for r in R_pool])
    rs = sorted(range(len(R_pool)), key=lambda i: PA[i])
    n5 = max(1, len(R_pool)*5//100)
    n_th = max(1, len(R_pool)*th//100)
    ea = [R_pool[i] for i in rs[n5:n_th]]
    ed = [R_pool[i] for i in rs[-(n_th):-(n5)] if i>=0]
    return ed, ea


# ══════════════════════════════════════════════════════════════════════════
#  TEST 1: POWER SIMULATION
#  
#  Question: Given the labelled effect sizes and the attenuation from
#  impure tails, how many features would we *expect* to show the correct
#  direction at each doughnut threshold?
#
#  Method: For each continuous feature, estimate the true effect size
#  (delta) from the labelled data, attenuate by λ, and simulate
#  bootstrapped direction tests at the doughnut sample sizes. For binary
#  features, simulate Fisher-test direction from the labelled rates
#  attenuated by λ.
# ══════════════════════════════════════════════════════════════════════════

print("="*70)
print("TEST 1: POWER SIMULATION — EXPECTED DIRECTION COUNTS")
print("="*70)

N_SIM = 2000
rng = np.random.RandomState(SEED)

# Compute labelled effect sizes for continuous features (per-letter rates)
# We need per-letter values, not pooled, for simulation
def per_letter_vals(group, fn):
    """Get the feature value for each individual letter."""
    return np.array([fn([r]) for r in group])

lab_effects = {}
for name, fn, exp in CONT:
    a_vals = per_letter_vals(A, fn)
    d_vals = per_letter_vals(D_att, fn)
    # Remove NaN
    a_vals = a_vals[~np.isnan(a_vals)]
    d_vals = d_vals[~np.isnan(d_vals)]
    lab_effects[name] = {
        'a_mean': np.mean(a_vals), 'a_std': np.std(a_vals, ddof=1),
        'd_mean': np.mean(d_vals), 'd_std': np.std(d_vals, ddof=1),
        'exp': exp,
        'type': 'cont'
    }

for name, key, exp in BIN:
    a_rate = sum(1 for r in A if r[key]==1) / len(A)
    d_rate = sum(1 for r in D_att if r[key]==1) / len(D_att)
    lab_effects[name] = {
        'a_rate': a_rate, 'd_rate': d_rate,
        'exp': exp,
        'type': 'bin'
    }

# λ values at each doughnut threshold (from pipeline output, but recompute)
def compute_lambda_doughnut(th):
    mu_a = np.mean([r['pl_resid'] for r in A])
    sd_a = np.std([r['pl_resid'] for r in A], ddof=1)
    mu_d = np.mean([r['pl_resid'] for r in D_att])
    sd_d = np.std([r['pl_resid'] for r in D_att], ddof=1)
    def post(x):
        la=norm.pdf(x,mu_a,sd_a); ld=norm.pdf(x,mu_d,sd_d)
        return (ld*PI_0)/(ld*PI_0+la*(1-PI_0))
    PA = np.array([post(r['pl_resid']) for r in R_att])
    rs = sorted(range(len(R_att)), key=lambda i: PA[i])
    n5 = max(1, len(R_att)*5//100)
    n_th = max(1, len(R_att)*th//100)
    ea_idx = rs[n5:n_th]
    ed_idx = [i for i in rs[-(n_th):-(n5)] if i>=0]
    pid = np.mean([PA[i] for i in ed_idx])
    pia = 1 - np.mean([PA[i] for i in ea_idx])
    lam = pid + pia - 1
    return lam, len(ea_idx), len(ed_idx)

print(f"\nSimulating {N_SIM} iterations per feature per threshold.\n")
print(f"For each feature, we draw samples from the labelled distributions,")
print(f"mixing according to λ (group purity), and check whether the")
print(f"observed direction matches the expected direction.\n")

thresholds = [10, 15, 20, 25]

# Header
print(f"{'Feature':14s}", end='')
for th in thresholds:
    print(f"  {th}%_P(dir)", end='')
print(f"  {'labelled δ':>10s}")
print("-"*70)

# Store per-feature power for summary
power_matrix = {}

for name, fn, exp in CONT:
    eff = lab_effects[name]
    powers = []
    for th in thresholds:
        lam, n_ea, n_ed = compute_lambda_doughnut(th)
        # Each tail is a mixture: eD has fraction (1+λ)/2 true Dict, rest Auto
        # eA has fraction (1+λ)/2 true Auto, rest Dict
        p_dict_in_ed = (1 + lam) / 2
        p_auto_in_ea = (1 + lam) / 2

        n_correct = 0
        for _ in range(N_SIM):
            # Draw eD sample: mix of Dict-like and Auto-like
            n_true_d = rng.binomial(n_ed, p_dict_in_ed)
            n_true_a_in_ed = n_ed - n_true_d
            vals_ed = np.concatenate([
                rng.normal(eff['d_mean'], max(eff['d_std'], 0.01), n_true_d),
                rng.normal(eff['a_mean'], max(eff['a_std'], 0.01), n_true_a_in_ed)
            ])
            # Draw eA sample
            n_true_a = rng.binomial(n_ea, p_auto_in_ea)
            n_true_d_in_ea = n_ea - n_true_a
            vals_ea = np.concatenate([
                rng.normal(eff['a_mean'], max(eff['a_std'], 0.01), n_true_a),
                rng.normal(eff['d_mean'], max(eff['d_std'], 0.01), n_true_d_in_ea)
            ])
            # Pooled rate for each group
            obs_d = np.mean(vals_ed)
            obs_a = np.mean(vals_ea)
            delta = obs_d - obs_a
            if exp == '+':
                correct = delta > 0
            else:
                correct = delta < 0
            if correct: n_correct += 1

        p_correct = n_correct / N_SIM
        powers.append(p_correct)

    delta_lab = eff['d_mean'] - eff['a_mean']
    power_matrix[name] = powers
    print(f"{name:14s}", end='')
    for p in powers:
        print(f"  {p:>8.1%}", end='')
    print(f"  {delta_lab:>+10.3f}")

# Binary features: simulate from binomial
for name, key, exp in BIN:
    eff = lab_effects[name]
    powers = []
    for th in thresholds:
        lam, n_ea, n_ed = compute_lambda_doughnut(th)
        p_dict_in_ed = (1 + lam) / 2
        p_auto_in_ea = (1 + lam) / 2

        n_correct = 0
        for _ in range(N_SIM):
            # eD: mixture
            n_true_d = rng.binomial(n_ed, p_dict_in_ed)
            n_true_a_in_ed = n_ed - n_true_d
            hits_ed = (rng.binomial(1, eff['d_rate'], n_true_d).sum() +
                       rng.binomial(1, eff['a_rate'], n_true_a_in_ed).sum())
            # eA: mixture
            n_true_a = rng.binomial(n_ea, p_auto_in_ea)
            n_true_d_in_ea = n_ea - n_true_a
            hits_ea = (rng.binomial(1, eff['a_rate'], n_true_a).sum() +
                       rng.binomial(1, eff['d_rate'], n_true_d_in_ea).sum())

            rate_ed = hits_ed / n_ed
            rate_ea = hits_ea / n_ea
            if exp == 'A>D':
                correct = rate_ea > rate_ed
            else:
                correct = rate_ed > rate_ea
            if correct: n_correct += 1

        p_correct = n_correct / N_SIM
        powers.append(p_correct)

    power_matrix[name] = powers
    print(f"{name:14s}", end='')
    for p in powers:
        print(f"  {p:>8.1%}", end='')
    print(f"  A:{eff['a_rate']:.2f} D:{eff['d_rate']:.2f}")

# Expected total direction count
print(f"\n{'EXPECTED #/9':14s}", end='')
for j, th in enumerate(thresholds):
    exp_n = sum(power_matrix[n][j] for n in power_matrix)
    print(f"  {exp_n:>8.1f}", end='')
print()

# Observed
print(f"{'OBSERVED #/9':14s}", end='')
observed_dirs = {10: 8, 15: 9, 20: 6, 25: 7}  # from pipeline
for th in thresholds:
    print(f"  {observed_dirs[th]:>8d}", end='')
print()

# P(observed or better) under simulation
print(f"{'P(≥obs)':14s}", end='')
for j, th in enumerate(thresholds):
    # Simulate joint direction counts
    feature_names = [n for n,_,_ in CONT] + [n for n,_,_ in BIN]
    joint_counts = np.zeros(N_SIM)
    # We already have per-feature power; simulate joint draws
    # Each feature independently correct with its own probability
    for _ in range(200):  # quick estimate
        pass
    # Better: just use the marginal probabilities (independence approximation)
    # P(≥k) from Poisson binomial
    probs = [power_matrix[n][j] for n in feature_names]
    # Exact Poisson binomial via DFT
    from functools import reduce
    def poisson_binom_pmf(ps):
        """Exact PMF of sum of independent Bernoullis with different probs."""
        n = len(ps)
        pmf = np.array([1.0 - ps[0], ps[0]])
        for i in range(1, n):
            new_pmf = np.zeros(len(pmf) + 1)
            new_pmf[:len(pmf)] += pmf * (1 - ps[i])
            new_pmf[1:len(pmf)+1] += pmf * ps[i]
            pmf = new_pmf
        return pmf

    pmf = poisson_binom_pmf(probs)
    p_ge_obs = sum(pmf[observed_dirs[th]:])
    print(f"  {p_ge_obs:>8.3f}", end='')
print()


# ══════════════════════════════════════════════════════════════════════════
#  TESTS 2 & 3: PERMUTATION OMNIBUS TESTS
#
#  Vectorized: precompute all per-letter feature values as arrays, then
#  permutation only shuffles indices and sums slices.
# ══════════════════════════════════════════════════════════════════════════

print("\n" + "="*70)
print("TESTS 2 & 3: PERMUTATION OMNIBUS (direction count + signed z-sum)")
print("="*70)

N_PERM = 2000

# Precompute per-letter arrays for all REST letters (Att only)
n_R = len(R_att)

# Continuous: per-letter numerator and token counts for pooled rates
cont_nums = {}  # name -> array of per-letter counts
cont_sign = {}  # +1 if Dict>Auto expected, -1 if Auto>Dict
for name, fn, exp in CONT:
    if name == 'velim':
        cont_nums[name] = np.array([r['velim_n'] for r in R_att])
    elif name == 'exclamations':
        cont_nums[name] = np.array([r['excl_n'] for r in R_att])
    elif name == 'si_et':
        cont_nums[name] = np.array([r['si_et_n'] for r in R_att])
    elif name == 'nec_ratio':
        cont_nums[name] = None  # handled specially
    elif name == 'ac_ratio':
        cont_nums[name] = None  # handled specially
    cont_sign[name] = 1 if exp == '+' else -1

tok_arr = np.array([r['tokens'] for r in R_att], dtype=float)
nec_arr = np.array([r['nec_n'] for r in R_att], dtype=float)
neque_arr = np.array([r['neque_n'] for r in R_att], dtype=float)
ac_atque_arr = np.array([r['ac_atque_n'] for r in R_att], dtype=float)
coord_arr = np.array([r['coord_n'] for r in R_att], dtype=float)

# Binary
bin_arrs = {}
bin_sign = {}
for name, key, exp in BIN:
    bin_arrs[name] = np.array([r[key] for r in R_att], dtype=float)
    bin_sign[name] = 1  # A>D means: eA rate > eD rate is correct

# Posterior model params (fixed — from labelled)
mu_a = np.mean([r['pl_resid'] for r in A])
sd_a = np.std([r['pl_resid'] for r in A], ddof=1)
mu_d = np.mean([r['pl_resid'] for r in D_att])
sd_d = np.std([r['pl_resid'] for r in D_att], ddof=1)

pl_arr_R = np.array([r['pl_resid'] for r in R_att])

def fast_doughnut_indices(pl_values, th):
    """Return (ed_idx, ea_idx) as index arrays into R, given pl_resid values."""
    la = norm.pdf(pl_values, mu_a, sd_a)
    ld = norm.pdf(pl_values, mu_d, sd_d)
    PA = (ld * PI_0) / (ld * PI_0 + la * (1 - PI_0))
    order = np.argsort(PA)
    n5 = max(1, n_R * 5 // 100)
    n_th = max(1, n_R * th // 100)
    ea_idx = order[n5:n_th]
    ed_idx = order[-n_th:-n5]
    return ed_idx, ea_idx

def fast_directions(ed_idx, ea_idx):
    """Count correct directions using precomputed arrays."""
    n_correct = 0
    n_ed = len(ed_idx); n_ea = len(ea_idx)

    # velim
    vd = cont_nums['velim'][ed_idx].sum() / tok_arr[ed_idx].sum() * 1000
    va = cont_nums['velim'][ea_idx].sum() / tok_arr[ea_idx].sum() * 1000
    if vd > va: n_correct += 1  # exp: +

    # exclamations
    vd = cont_nums['exclamations'][ed_idx].sum() / tok_arr[ed_idx].sum() * 1000
    va = cont_nums['exclamations'][ea_idx].sum() / tok_arr[ea_idx].sum() * 1000
    if vd > va: n_correct += 1  # exp: +

    # nec_ratio
    nd = nec_arr[ed_idx].sum(); nqd = neque_arr[ed_idx].sum()
    na = nec_arr[ea_idx].sum(); nqa = neque_arr[ea_idx].sum()
    if (nd+nqd) > 0 and (na+nqa) > 0:
        rd = nd/(nd+nqd); ra = na/(na+nqa)
        if rd > ra: n_correct += 1  # exp: +

    # ac_ratio
    ad = ac_atque_arr[ed_idx].sum(); cd = coord_arr[ed_idx].sum()
    aa = ac_atque_arr[ea_idx].sum(); ca = coord_arr[ea_idx].sum()
    if cd > 0 and ca > 0:
        rd = ad/cd; ra = aa/ca
        if rd < ra: n_correct += 1  # exp: - (Auto higher)

    # si_et
    vd = cont_nums['si_et'][ed_idx].sum() / tok_arr[ed_idx].sum() * 1000
    va = cont_nums['si_et'][ea_idx].sum() / tok_arr[ea_idx].sum() * 1000
    if vd > va: n_correct += 1  # exp: +

    # Binary: A>D means eA should have higher rate
    for name, key, exp in BIN:
        rd = bin_arrs[name][ed_idx].sum() / n_ed
        ra = bin_arrs[name][ea_idx].sum() / n_ea
        if ra > rd: n_correct += 1

    return n_correct

def fast_signed_z(ed_idx, ea_idx):
    """Sum of signed z-scores using precomputed arrays."""
    n_ed = len(ed_idx); n_ea = len(ea_idx)
    zsum = 0.0

    # Helper: pooled rate z-score for count-based features
    def rate_z(nums_key, sign):
        nd = cont_nums[nums_key][ed_idx].sum()
        td = tok_arr[ed_idx].sum()
        na = cont_nums[nums_key][ea_idx].sum()
        ta = tok_arr[ea_idx].sum()
        rd = nd/td*1000; ra = na/ta*1000
        # Per-letter rates for SE
        all_idx = np.concatenate([ed_idx, ea_idx])
        per_letter = cont_nums[nums_key][all_idx] / tok_arr[all_idx] * 1000
        se = np.std(per_letter, ddof=1) / np.sqrt(n_ed)
        if se == 0: return 0
        return sign * (rd - ra) / se

    zsum += rate_z('velim', +1)
    zsum += rate_z('exclamations', +1)
    zsum += rate_z('si_et', +1)

    # nec_ratio
    all_idx = np.concatenate([ed_idx, ea_idx])
    nec_all = nec_arr[all_idx]; neq_all = neque_arr[all_idx]
    per_letter_nr = np.where(nec_all+neq_all > 0, nec_all/(nec_all+neq_all), np.nan)
    valid = per_letter_nr[~np.isnan(per_letter_nr)]
    if len(valid) > 5:
        nd = nec_arr[ed_idx].sum(); nqd = neque_arr[ed_idx].sum()
        na = nec_arr[ea_idx].sum(); nqa = neque_arr[ea_idx].sum()
        if (nd+nqd)>0 and (na+nqa)>0:
            rd = nd/(nd+nqd); ra = na/(na+nqa)
            se = np.std(valid, ddof=1) / np.sqrt(n_ed)
            if se > 0: zsum += (rd - ra) / se  # exp: +

    # ac_ratio
    ac_all = ac_atque_arr[all_idx]; co_all = coord_arr[all_idx]
    per_letter_ac = np.where(co_all > 0, ac_all/co_all, np.nan)
    valid = per_letter_ac[~np.isnan(per_letter_ac)]
    if len(valid) > 5:
        ad = ac_atque_arr[ed_idx].sum(); cd = coord_arr[ed_idx].sum()
        aa = ac_atque_arr[ea_idx].sum(); ca = coord_arr[ea_idx].sum()
        if cd > 0 and ca > 0:
            rd = ad/cd; ra = aa/ca
            se = np.std(valid, ddof=1) / np.sqrt(n_ed)
            if se > 0: zsum += -1 * (rd - ra) / se  # exp: - (flip sign)

    # Binary
    for name, key, exp in BIN:
        rd = bin_arrs[name][ed_idx].sum() / n_ed
        ra = bin_arrs[name][ea_idx].sum() / n_ea
        p_pool = bin_arrs[name][np.concatenate([ed_idx,ea_idx])].mean()
        if p_pool == 0 or p_pool == 1: continue
        se = np.sqrt(p_pool*(1-p_pool)*(1/n_ed + 1/n_ea))
        if se == 0: continue
        zsum += (ra - rd) / se  # A>D: positive when eA > eD

    return zsum

print(f"\nPermuting pl_resid among REST letters ({N_PERM} permutations).\n")

rng_perm = np.random.RandomState(SEED + 999)

for th in thresholds:
    # Observed
    ed_idx_obs, ea_idx_obs = fast_doughnut_indices(pl_arr_R, th)
    if len(ed_idx_obs) < 3 or len(ea_idx_obs) < 3:
        print(f"  {th}%: too few letters, skipping"); continue
    obs_k = fast_directions(ed_idx_obs, ea_idx_obs)
    obs_z = fast_signed_z(ed_idx_obs, ea_idx_obs)

    null_counts = np.zeros(N_PERM, dtype=int)
    null_zscores = np.zeros(N_PERM)

    for perm_i in range(N_PERM):
        perm_pl = rng_perm.permutation(pl_arr_R)
        ed_idx_p, ea_idx_p = fast_doughnut_indices(perm_pl, th)
        # NB: indices still reference the SAME feature arrays (features not permuted)
        null_counts[perm_i] = fast_directions(ed_idx_p, ea_idx_p)
        null_zscores[perm_i] = fast_signed_z(ed_idx_p, ea_idx_p)

    p_dir = np.mean(null_counts >= obs_k)
    p_z = np.mean(null_zscores >= obs_z)

    print(f"  Doughnut {th}%:")
    print(f"    DIRECTION COUNT:")
    print(f"      Observed: {obs_k}/9")
    print(f"      Null mean: {np.mean(null_counts):.1f}/9")
    print(f"      Null distribution: ", end='')
    for k in range(10):
        frac = np.mean(null_counts == k)
        if frac > 0.005: print(f"{k}:{frac:.1%} ", end='')
    print()
    print(f"      P(≥{obs_k}/9) = {p_dir:.4f}")
    print(f"    SIGNED Z-SUM:")
    print(f"      Observed Σz = {obs_z:.2f}")
    print(f"      Null: mean={np.mean(null_zscores):.2f}, SD={np.std(null_zscores):.2f}")
    print(f"      P(≥observed) = {p_z:.4f}")
    print()

print("="*70)
print("DONE")
print("="*70)
