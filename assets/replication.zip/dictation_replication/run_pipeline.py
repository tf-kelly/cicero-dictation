#!/usr/bin/env python3
"""Final pipeline: 5 continuous + 4 binary features, no splits, no qq_share, no ego."""

import csv, re, numpy as np
from scipy import stats
from scipy.stats import norm, spearmanr, mannwhitneyu

SEED = 42; N_BOOT = 2000; PI_0 = 0.30

from pathlib import Path
DATA_DIR = Path(__file__).parent / "data"

# ── Load ──────────────────────────────────────────────────────────────────

letters = {}
with open(DATA_DIR / 'units.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        letters[row['unit_id']] = {'text': row['text'], 'label': row['label']}

scores_pl = {}; scores_sd = {}
with open(DATA_DIR / 'scores_ge5.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        scores_pl[row['unit_id']] = float(row['prop_late_last_third_resid'])
        scores_sd[row['unit_id']] = float(row['sd_root_pos_rel_resid'])

combined = {}
with open(DATA_DIR / 'combined_corpus_features.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        combined[row['uid']] = row

fam_text = {}
with open(DATA_DIR / 'cicero_ad_fam_from_cicero.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        fam_text[row['unit_id']] = row['text']
qfr_text = {}
with open(DATA_DIR / 'cicero_ad_quintum_fratrem.csv', newline='', encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        qfr_text[row['unit_id']] = row['text']

dates = {}
with open(DATA_DIR / 'cicero_atticus_unit_id_date_with_sb__1_.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        m = re.search(r'(\d+)\s*BCE', row['date'])
        if m: dates[row['unit_id']] = -int(m.group(1))

# ── Helpers ───────────────────────────────────────────────────────────────

def strip_sal_att(t):
    return re.sub(r'^(?:Scr\..*?\.\s*)?CICERO\s+ATTICO\s+salutem\b','',t,flags=re.I).strip()
def strip_sal_fam(t):
    t = re.sub(r'^Scr\.\s+[^.]+\.\s*', '', t).strip()
    return re.sub(r'^[A-Z\s.]+S\.\s*D\.\s*', '', t).strip()
def strip_sal_qfr(t):
    return re.sub(r'^.*?(?:FRATRI\s+SALUTEM|S\.\s*D\.)', '', t, flags=re.I).strip()
def tokenize(t):
    return re.findall(r'\b[a-zA-Z\u00C0-\u024F]+\b', t.lower())

OATH_PAT = [r'\bme\s*hercule\b', r'\bhercle\b', r'\bobsecro\b']  # oaths component of exclamations

def count_o(text, clean):
    """Count exclamatory 'o', excluding Greek transliteration contexts."""
    n = 0
    for m in re.finditer(r'\bo\b', clean):
        after = clean[m.end():m.end()+20]
        if re.match(r'\s*[\(\)\\=/]', after):
            continue
        n += 1
    return n
FI_PAT = [r'\bscito\b',r'\bfacito\b',r'\bmemento\b',r'\bhabeto\b',
           r'\bvideto\b',r'\bmittito\b',r'\bcurato\b',r'\bcaveto\b',r'\bdicito\b']
LP_PAT = [r'\b\w+avisse\b',r'\b\w+aviss(?:em|et|ent|es)\b',r'\b\w+averunt\b',
           r'\b\w+avisti(?:s)?\b',r'\b\w+aver(?:at|am|as|ant|amus)\b',
           r'\b\w+aver(?:it|im|is|int|o|imus)\b']
# NB: petiv-/quaesiv-/sciv-/novisse/consuev- removed (not 1st conjugation).
# 2nd-conj stems ending in -av- (caveo, faveo, paveo, laveo) excluded below.
LP_EXCLUDE_STEMS = {'cav', 'fav', 'pav', 'lav'}

def has_long_perf(text):
    """Check for 1st-conjugation long (uncontracted) perfect forms."""
    for pat in LP_PAT:
        for m in re.finditer(pat, text, re.I):
            word = m.group().lower()
            stem_m = re.match(r'(\w+?)av', word)
            if stem_m and stem_m.group(1) in LP_EXCLUDE_STEMS:
                continue
            return True
    return False

QUE_EXCL = {'neque','quoque','usque','quaque','undique','ubique','denique',
    'itaque','atque','namque','quisque','quemque','quamque','quibusque',
    'cuiusque','cuique','quidque','quaeque','quodque','uterque','utrique',
    'utrumque','utriusque','utroque','utramque','utraque','cumque',
    'quicumque','quaecumque','quodcumque','quocumque','quacumque',
    'quemcumque','quamcumque','quibuscumque','cuicumque','ubicumque',
    'undecumque','quandocumque','qualiscumque','qualecumque','qualicumque',
    'qualescumque','quantulacumque','quantuscumque','utique','aeque',
    'quinque','plerumque','plerique','pleraque','quousque'}

# Adversative quamquam: manually reviewed lookup (see data/quamquam_adv_reviewed.csv)
QQ_ADV_REVIEWED = {}
with open(DATA_DIR / 'quamquam_adv_reviewed.csv', newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        QQ_ADV_REVIEWED[row['letter_id']] = int(row['adv_count'])

def count_qq_adv(uid, text):
    """Return adversative quamquam count from manual review (Att letters).
    Falls back to post-punctuation heuristic for non-Att letters."""
    if uid in QQ_ADV_REVIEWED:
        return QQ_ADV_REVIEWED[uid]
    # Fallback for Fam/Qfr: original post-punctuation heuristic
    n = 0
    for m in re.finditer(r'\bquamquam\b', text, re.I):
        before = text[max(0, m.start()-3):m.start()].strip()
        if not re.search(r'[.!?;]$', before): continue
        n += 1
    return n

def count_si_et(text, clean):
    n = len(re.findall(r'[.!?;]\s+[Ee]t\b', clean))
    if re.match(r'\s*[Ee]t\b', clean): n += 1
    return n

def featurize(uid, text_raw, clean, n_tokens):
    nec = len(re.findall(r'\bnec\b', clean, re.I))
    neque = len(re.findall(r'\bneque\b', clean, re.I))
    atque_n = len(re.findall(r'\batque\b', clean, re.I))
    ac_n = len(re.findall(r'\bac\b', clean, re.I))
    et_n = len(re.findall(r'\bet\b', clean, re.I))
    que_w = [w for w in re.findall(r'\b[a-zA-Z\u00C0-\u024F]+que\b', clean.lower()) if w not in QUE_EXCL]
    coord = et_n + atque_n + ac_n + len(que_w)
    return {
        'tokens': n_tokens,
        'velim_n': len(re.findall(r'\bvelim\b', text_raw, re.I)),
        'excl_n': sum(len(re.findall(p, text_raw, re.I)) for p in OATH_PAT) + count_o(text_raw, clean),
        'nec_n': nec, 'neque_n': neque,
        'ac_atque_n': ac_n + atque_n, 'coord_n': coord,
        'si_et_n': count_si_et(text_raw, clean),
        'fi_p': 1 if sum(len(re.findall(p, text_raw, re.I)) for p in FI_PAT) > 0 else 0,
        'lp_p': 1 if has_long_perf(text_raw) else 0,
        'ea_p': 1 if len(re.findall(r'\bego\s+autem\b', text_raw, re.I)) > 0 else 0,
        'qq_adv_p': 1 if count_qq_adv(uid, text_raw) > 0 else 0,
    }

# ── Build corpus ──────────────────────────────────────────────────────────

all_letters = []

# Att (whole letters, no splits)
for uid, info in letters.items():
    if uid not in scores_pl: continue
    text_raw = info['text']
    clean = strip_sal_att(text_raw)
    toks = tokenize(clean)
    n = len(toks)
    if n < 20: continue
    feat = featurize(uid, text_raw, clean, n)
    feat.update({'uid': uid, 'corpus': 'Att', 'label': info['label'],
                 'pl_resid': scores_pl[uid], 'sd_resid': scores_sd[uid]})
    all_letters.append(feat)

# Fam/Qfr REST
for uid_full, row in combined.items():
    corpus = row['corpus']
    if corpus == 'Att': continue
    label = row['label']
    short = uid_full.replace('fam_','').replace('qfr_','')
    if corpus == 'Fam' and short in fam_text:
        text_raw = fam_text[short]; clean = strip_sal_fam(text_raw)
    elif corpus == 'Qfr' and short in qfr_text:
        text_raw = qfr_text[short]; clean = strip_sal_qfr(text_raw)
    else: continue
    toks = tokenize(clean)
    n = len(toks)
    if n < 20: continue
    feat = featurize(short, text_raw, clean, n)
    feat.update({'uid': uid_full, 'corpus': corpus, 'label': label,
                 'pl_resid': float(row['pl_resid']),
                 'sd_resid': float(combined[uid_full].get('pl_resid', '0'))})
    # sd_resid not in combined for fam/qfr — use fam_qfr file
    all_letters.append(feat)

# Load fam/qfr sd_resid
fq_sd = {}
try:
    with open(DATA_DIR / 'fam_qfr_syntax_scores.csv', newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            fq_sd[row['uid']] = float(row['sd_root_pos_rel_resid'])
except: pass

for r in all_letters:
    if r['corpus'] != 'Att' and r['uid'] in fq_sd:
        r['sd_resid'] = fq_sd[r['uid']]

A = [r for r in all_letters if r['label']=='Auto']  # All Auto (Att only, no Auto in Fam/Qfr)
D_att = [r for r in all_letters if r['label']=='Dict' and r['corpus']=='Att']
D_qfr = [r for r in all_letters if r['label']=='Dict' and r['corpus']=='Qfr']
D_all = D_att + D_qfr  # For enrichment posterior model
R = [r for r in all_letters if r['label']=='Rest']
R_att = [r for r in R if r['corpus']=='Att']

# §2 and Path B use Att-only labelled: A + D_att
# Path A enrichment uses R_att (368 Att letters); expanded R (496) as robustness check

# ── Feature definitions ───────────────────────────────────────────────────

def rate_k(g, key):
    t = sum(r[key] for r in g); n = sum(r['tokens'] for r in g)
    return t/n*1000 if n>0 else 0

def nec_ratio(g):
    n = sum(r['nec_n'] for r in g); q = sum(r['neque_n'] for r in g)
    return n/(n+q) if (n+q)>0 else np.nan

def lit_share(g):
    l = sum(r['ac_atque_n'] for r in g); t = sum(r['coord_n'] for r in g)
    return l/t if t>0 else np.nan

CONT = [
    ('velim',     lambda g: rate_k(g,'velim_n'), '+'),
    ('exclamations',     lambda g: rate_k(g,'excl_n'),  '+'),
    ('nec_ratio', nec_ratio,                      '+'),
    ('ac_ratio',  lit_share,                      '-'),
    ('si_et',     lambda g: rate_k(g,'si_et_n'), '+'),
]

BIN = [
    ('fut imp',   'fi_p',     'A>D'),
    ('long perf', 'lp_p',     'A>D'),
    ('ego autem', 'ea_p',     'A>D'),
    ('qq_adv',    'qq_adv_p', 'A>D'),
]

N_FEATURES = len(CONT) + len(BIN)  # 9
N_DROPPED_PRESCREENING = 1  # si_sed (dropped for chrono confound before enrichment)
N_DROPPED_SCREENING = 2     # ego_nom, qq_share (dropped at Lab+5% screening)
N_BH = N_FEATURES + N_DROPPED_SCREENING  # 11

def dir_c(delta, exp):
    if delta is None: return False
    return ('+' if delta>0 else '-') == exp

def dir_b(ra, rd, exp):
    return ra > rd if exp=='A>D' else rd > ra

def boot(gd, ga, fn, nb=N_BOOT, seed=SEED):
    od=fn(gd); oa=fn(ga)
    if od is None or oa is None: return None, 1.0
    if isinstance(od,float) and np.isnan(od): return None, 1.0
    if isinstance(oa,float) and np.isnan(oa): return None, 1.0
    delta=od-oa; pool=gd+ga; nd=len(gd)
    rng=np.random.RandomState(seed); nulls=[]
    for _ in range(nb):
        ix=rng.choice(len(pool),len(pool),replace=True)
        vd=fn([pool[i] for i in ix[:nd]]); va=fn([pool[i] for i in ix[nd:]])
        if vd is not None and va is not None and not(isinstance(vd,float) and np.isnan(vd)):
            nulls.append(vd-va)
    return delta, np.mean(np.abs(nulls)>=abs(delta)) if nulls else 1.0

def cboot(gd, ga, fn, lam, nb=N_BOOT, seed=SEED):
    od=fn(gd); oa=fn(ga)
    if od is None or oa is None: return None, 1.0
    if isinstance(od,float) and np.isnan(od): return None, 1.0
    if isinstance(oa,float) and np.isnan(oa): return None, 1.0
    delta=od-oa; pool=gd+ga; nd=len(gd)
    rng=np.random.RandomState(seed); nulls=[]
    for _ in range(nb):
        ix=rng.choice(len(pool),len(pool),replace=True)
        vd=fn([pool[i] for i in ix[:nd]]); va=fn([pool[i] for i in ix[nd:]])
        if vd is not None and va is not None and not(isinstance(vd,float) and np.isnan(vd)):
            nulls.append(vd-va)
    if not nulls or lam<=0: return delta, 1.0
    se=np.std(nulls,ddof=1)
    if se==0: return delta, 1.0
    return delta, 2*(1-norm.cdf(abs(delta/lam)/se))

def fp(p):
    if p<0.0001: return '<0.0001*'
    if p<0.001: return f'{p:.4f}*'
    if p<0.05: return f'{p:.3f}*'
    return f'{p:.3f}'

def get_tails(R_pool, sort_key, th, pi=PI_0):
    """Sort REST, return (lam, ed, ea) at threshold th%."""
    vals = np.array([r[sort_key] for r in R_pool])
    mu_a = np.mean([r[sort_key] for r in A])
    sd_a = np.std([r[sort_key] for r in A], ddof=1)
    mu_d = np.mean([r[sort_key] for r in D_att])
    sd_d = np.std([r[sort_key] for r in D_att], ddof=1)
    def post(x):
        la=norm.pdf(x,mu_a,sd_a); ld=norm.pdf(x,mu_d,sd_d)
        return (ld*pi)/(ld*pi+la*(1-pi))
    PA = np.array([post(r[sort_key]) for r in R_pool])
    rs = sorted(range(len(R_pool)), key=lambda i: PA[i])
    n_tail = max(1, len(R_pool)*th//100)
    ea = [R_pool[i] for i in rs[:n_tail]]
    ed = [R_pool[i] for i in rs[-n_tail:]]
    pid = np.mean([post(r[sort_key]) for r in ed])
    pia = 1-np.mean([post(r[sort_key]) for r in ea])
    return pid+pia-1, ed, ea, rs

def get_doughnut(R_pool, sort_key, th, pi=PI_0):
    vals = np.array([r[sort_key] for r in R_pool])
    mu_a = np.mean([r[sort_key] for r in A])
    sd_a = np.std([r[sort_key] for r in A], ddof=1)
    mu_d = np.mean([r[sort_key] for r in D_att])
    sd_d = np.std([r[sort_key] for r in D_att], ddof=1)
    def post(x):
        la=norm.pdf(x,mu_a,sd_a); ld=norm.pdf(x,mu_d,sd_d)
        return (ld*pi)/(ld*pi+la*(1-pi))
    PA = np.array([post(r[sort_key]) for r in R_pool])
    rs = sorted(range(len(R_pool)), key=lambda i: PA[i])
    n5 = max(1, len(R_pool)*5//100)
    n_th = max(1, len(R_pool)*th//100)
    ea = [R_pool[i] for i in rs[n5:n_th]]
    ed = [R_pool[i] for i in rs[-(n_th):-(n5)] if i>=0]
    pid = np.mean([post(r[sort_key]) for r in ed])
    pia = 1-np.mean([post(r[sort_key]) for r in ea])
    return pid+pia-1, ed, ea, rs

def test_features(ed, ea, lam, seed=SEED):
    """Return list of (name, delta_or_rates, direction_ok, p)."""
    results = []
    for name, fn, exp in CONT:
        d, p = cboot(ed, ea, fn, lam, seed=seed)
        ok = dir_c(d, exp) if d is not None else False
        results.append((name, d, ok, p))
    for name, key, exp in BIN:
        dy=sum(1 for r in ed if r[key]==1); ay=sum(1 for r in ea if r[key]==1)
        _,p=stats.fisher_exact([[dy,len(ed)-dy],[ay,len(ea)-ay]])
        ra=ay/len(ea) if ea else 0; rd=dy/len(ed) if ed else 0
        ok = dir_b(ra, rd, exp)
        results.append((name, (ra,rd), ok, p))
    return results

# ══════════════════════════════════════════════════════════════════════════
print("="*70)
print("FINAL PIPELINE")
print("="*70)
print(f"\nCorpus: {len(A)} Auto, {len(D_att)} Dict(Att) + {len(D_qfr)} Dict(Qfr), {len(R)} Rest")
print(f"  Att labelled: {len(A)} Auto, {len(D_att)} Dict")
print(f"  REST (main): {len(R_att)} Att")
print(f"  REST (robustness): {len(R_att)} Att + "
      f"{sum(1 for r in R if r['corpus']!='Att')} Fam/Qfr = {len(R)}")
print(f"  Features: {N_FEATURES} retained ({len(CONT)} continuous, {len(BIN)} binary)")
print(f"  Dropped at screening: {N_DROPPED_SCREENING} (BH denominator: {N_BH})")
print(f"  Dropped pre-screening (chrono confounds): {N_DROPPED_PRESCREENING}")
print(f"  Note: §2 and Path B use Att-only labelled ({len(A)} A, {len(D_att)} D).")
print(f"        Enrichment posterior uses Att-only Dict distribution.")

# ── §2: Labelled ─────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§2. LABELLED FEATURE COMPARISON")
print("="*70)
print(f"\n{'Feature':12s} {'Auto':>8s} {'Dict':>8s} {'p':>10s} {'dir':>4s}")
print("-"*42)

for name, fn, exp in CONT:
    va=fn(A); vd=fn(D_att); delta,p=boot(D_att,A,fn)
    d='✓' if dir_c(delta,exp) else '✗'
    print(f'{name:12s} {va:>8.3f} {vd:>8.3f} {fp(p):>10s} {d:>4s}')

for name, key, exp in BIN:
    ay=sum(1 for r in A if r[key]==1); dy=sum(1 for r in D_att if r[key]==1)
    _,p=stats.fisher_exact([[dy,len(D_att)-dy],[ay,len(A)-ay]])
    d='✓' if (ay/len(A)>dy/len(D_att) if exp=='A>D' else dy/len(D_att)>ay/len(A)) else '✗'
    print(f'{name:12s} {ay}/{len(A)}({ay/len(A)*100:4.0f}%) '
          f'{dy}/{len(D_att)}({dy/len(D_att)*100:4.0f}%) {fp(p):>10s} {d:>4s}')

# ── §3: AUC ──────────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§3. SYNTAX SEPARATION")
print("="*70)

for sort_name, sort_key in [('pl_resid','pl_resid'), ('sd_resid','sd_resid')]:
    a_vals = np.array([r[sort_key] for r in A])
    d_vals = np.array([r[sort_key] for r in D_att])
    u, mw_p = mannwhitneyu(d_vals, a_vals, alternative='two-sided')
    auc = max(u/(len(d_vals)*len(a_vals)), 1-u/(len(d_vals)*len(a_vals)))
    print(f"  {sort_name}: AUC = {auc:.3f}, MW p = {mw_p:.6f}")

# ── Figure 1: KDE density by LP ──────────────────────────────────────────

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from scipy.stats import gaussian_kde
    from matplotlib.gridspec import GridSpec

    fig_path = DATA_DIR / '..' / 'figure1.pdf'

    a_lp = np.array([r['pl_resid'] for r in A])
    d_lp = np.array([r['pl_resid'] for r in D_att])
    r_lp = np.array([r['pl_resid'] for r in R_att])

    x_lo = min(np.min(a_lp), np.min(d_lp), np.min(r_lp)) - 0.06
    x_hi = max(np.max(a_lp), np.max(d_lp), np.max(r_lp)) + 0.06
    x_grid = np.linspace(x_lo, x_hi, 500)

    # Silverman bandwidth scaled up for smoothness matching original
    bw = 0.45

    kde_a = gaussian_kde(a_lp, bw_method=bw)
    kde_d = gaussian_kde(d_lp, bw_method=bw)
    kde_r = gaussian_kde(r_lp, bw_method=bw)

    # ── Layout: KDE on top (tall), strip plot on bottom (short) ──
    fig = plt.figure(figsize=(8, 5.2))
    gs = GridSpec(2, 1, height_ratios=[3.5, 1], hspace=0.06, figure=fig)
    ax_kde = fig.add_subplot(gs[0])
    ax_strip = fig.add_subplot(gs[1], sharex=ax_kde)

    # Colours
    c_auto, c_dict, c_rest = '#2166ac', '#b2182b', '#666666'

    # ── Upper panel: KDE ──
    ax_kde.fill_between(x_grid, kde_r(x_grid), alpha=0.12, color=c_rest)
    ax_kde.plot(x_grid, kde_r(x_grid), color=c_rest, lw=1.8, ls='-.', 
                label=f'REST (n = {len(R_att)})')

    ax_kde.fill_between(x_grid, kde_a(x_grid), alpha=0.18, color=c_auto)
    ax_kde.plot(x_grid, kde_a(x_grid), color=c_auto, lw=2, ls='-', 
                label=f'AUTO (n = {len(A)})')

    ax_kde.fill_between(x_grid, kde_d(x_grid), alpha=0.18, color=c_dict)
    ax_kde.plot(x_grid, kde_d(x_grid), color=c_dict, lw=2.5, ls='--', 
                label=f'DICT (n = {len(D_att)})')

    ax_kde.axvline(0, color='grey', lw=0.6, ls=':')
    ax_kde.set_ylabel('Density', fontsize=10)
    ax_kde.legend(frameon=True, framealpha=0.9, edgecolor='#cccccc', fontsize=9, loc='upper left')
    ax_kde.spines['top'].set_visible(False)
    ax_kde.spines['right'].set_visible(False)
    ax_kde.spines['bottom'].set_visible(False)
    ax_kde.tick_params(axis='x', which='both', bottom=False, labelbottom=False)
    ax_kde.tick_params(axis='y', labelsize=9)
    ax_kde.set_xlim(x_lo, x_hi)

    # ── Lower panel: strip / scatter ──
    rng_jit = np.random.RandomState(42)
    jitter = 0.12

    y_auto, y_dict, y_rest = 2, 1, 0
    ax_strip.scatter(a_lp, y_auto + rng_jit.uniform(-jitter, jitter, len(a_lp)),
                     s=18, alpha=0.6, color=c_auto, edgecolors='none')
    ax_strip.scatter(d_lp, y_dict + rng_jit.uniform(-jitter, jitter, len(d_lp)),
                     s=18, alpha=0.6, color=c_dict, edgecolors='none')
    ax_strip.scatter(r_lp, y_rest + rng_jit.uniform(-jitter, jitter, len(r_lp)),
                     s=10, alpha=0.35, color=c_rest, edgecolors='none')

    ax_strip.axvline(0, color='grey', lw=0.6, ls=':')
    ax_strip.set_yticks([y_rest, y_dict, y_auto])
    ax_strip.set_yticklabels(['REST', 'DICT', 'AUTO'], fontsize=9)
    ax_strip.set_ylim(-0.4, 2.5)
    ax_strip.spines['top'].set_visible(False)
    ax_strip.spines['right'].set_visible(False)
    ax_strip.tick_params(axis='x', labelsize=9)
    ax_strip.set_xlabel('Residualized proportion of predicates in final third\n'
                        '(0 = expected value for a letter of this length, given AUTO baseline)',
                        fontsize=9)

    fig.savefig(fig_path, dpi=300, bbox_inches='tight')
    plt.close(fig)
    print(f"\n  Figure 1 saved to {fig_path}")
except ImportError:
    print("\n  (matplotlib not available — skipping Figure 1)")

# ── Lab+5% screening ─────────────────────────────────────────────────────

print("\n" + "="*70)
print("LAB+5% SCREENING (directional check)")
print("="*70)

lam5, ed5, ea5, rs_pl = get_tails(R_att, 'pl_resid', 5)
res5 = test_features(ed5, ea5, lam5)
for name, val, ok, p in res5:
    print(f"  {name:12s}: {'✓' if ok else '✗':>3s}  p={fp(p)}")

# ── §4: Doughnut ──────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§4. DOUGHNUT TEST (5% exclusion zone)")
print("="*70)

for th in [10, 15, 20, 25]:
    lam, dd, da, _ = get_doughnut(R_att, 'pl_resid', th)
    if len(da)<3 or len(dd)<3: continue
    res = test_features(dd, da, lam, seed=SEED+th)
    nc = sum(1 for _,_,ok,_ in res if ok)
    nt = len(res)
    bp = 1-stats.binom.cdf(nc-1,nt,0.5)
    wrong = [n for n,_,ok,_ in res if not ok]
    print(f"  {th}%: nA={len(da):3d}  nD={len(dd):3d}  λ={lam:.3f}  "
          f"Dir={nc}/{nt}  p={bp:.4f}  wrong: {', '.join(wrong) if wrong else 'none'}")

# ── Robustness: expanded REST (Att + Fam/Qfr = 496) ──────────────────────

print(f"\n  Robustness: doughnut with expanded REST ({len(R)} letters, incl. Fam/Qfr)")
for th in [10, 15, 20, 25]:
    lam, dd, da, _ = get_doughnut(R, 'pl_resid', th)
    if len(da)<3 or len(dd)<3: continue
    res = test_features(dd, da, lam, seed=SEED+th)
    nc = sum(1 for _,_,ok,_ in res if ok)
    nt = len(res)
    bp = 1-stats.binom.cdf(nc-1,nt,0.5)
    print(f"  {th}%: nA={len(da):3d}  nD={len(dd):3d}  λ={lam:.3f}  Dir={nc}/{nt}  p={bp:.4f}")

# ── Path B ────────────────────────────────────────────────────────────────

print("\n" + "="*70)
print("PATH B: AUGMENTATION (4 binary markers)")
print("="*70)

auto_pl = np.array([r['pl_resid'] for r in A])
dict_pl = np.array([r['pl_resid'] for r in D_att])
u0,_ = mannwhitneyu(auto_pl, dict_pl, alternative='two-sided')
base_auc = max(u0/(len(auto_pl)*len(dict_pl)), 1-u0/(len(auto_pl)*len(dict_pl)))

for mname, mkey in [('fut imp','fi_p'),('long perf','lp_p'),('ego autem','ea_p'),('qq_adv','qq_adv_p')]:
    marked = [r for r in R_att if r[mkey]==1]
    n_m = len(marked)
    if n_m==0: print(f"  {mname}: 0 marked, skip"); continue
    aug = np.concatenate([auto_pl, [r['pl_resid'] for r in marked]])
    u2,_ = mannwhitneyu(aug, dict_pl, alternative='two-sided')
    aauc = max(u2/(len(aug)*len(dict_pl)), 1-u2/(len(aug)*len(dict_pl)))
    rng3 = np.random.RandomState(SEED); nb=0
    for _ in range(2000):
        s=rng3.choice(len(R_att),n_m,replace=False)
        spl=np.concatenate([auto_pl,[R_att[i]['pl_resid'] for i in s]])
        u3,_=mannwhitneyu(spl,dict_pl,alternative='two-sided')
        rauc=max(u3/(len(spl)*len(dict_pl)),1-u3/(len(spl)*len(dict_pl)))
        if rauc>=aauc: nb+=1
    mv=np.array([r[mkey] for r in R_att]); pv=np.array([r['pl_resid'] for r in R_att])
    rho,rp=spearmanr(mv,pv)
    print(f"  {mname:12s}: n={n_m:3d}, AUC={aauc:.3f} (base={base_auc:.3f}), "
          f"beats {(2000-nb)/2000*100:.1f}%, ρ(pl)={rho:+.3f}")

any_m = [r for r in R_att if r['fi_p']==1 or r['lp_p']==1 or r['ea_p']==1 or r['qq_adv_p']==1]
aug_all = np.concatenate([auto_pl, [r['pl_resid'] for r in any_m]])
u4,_=mannwhitneyu(aug_all,dict_pl,alternative='two-sided')
auc4=max(u4/(len(aug_all)*len(dict_pl)),1-u4/(len(aug_all)*len(dict_pl)))
rng4=np.random.RandomState(SEED);nb4=0
for _ in range(2000):
    s=rng4.choice(len(R_att),len(any_m),replace=False)
    spl=np.concatenate([auto_pl,[R_att[i]['pl_resid'] for i in s]])
    u5,_=mannwhitneyu(spl,dict_pl,alternative='two-sided')
    rauc=max(u5/(len(spl)*len(dict_pl)),1-u5/(len(spl)*len(dict_pl)))
    if rauc>=auc4: nb4+=1
print(f"\n  ALL 4 combined: n={len(any_m)}, AUC={auc4:.3f}, beats {(2000-nb4)/2000*100:.1f}%")

# ── §6: Base rate ─────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§6. BASE RATE ESTIMATION")
print("="*70)

# ── Method 1: Joint ML (rate features + binary markers) ──────────────────

# Compute per-letter rates
for r in all_letters:
    r['velim_rate'] = r['velim_n'] / r['tokens'] * 1000
    r['excl_rate'] = r['excl_n'] / r['tokens'] * 1000
    r['si_et_rate'] = r['si_et_n'] / r['tokens'] * 1000

ML_RATE_NAMES = ['velim_rate', 'excl_rate', 'si_et_rate']

# Fit Gaussians from Att labelled
ml_gauss = {}
for name in ML_RATE_NAMES:
    a_v = np.array([r[name] for r in A])
    d_v = np.array([r[name] for r in D_att])
    ml_gauss[name] = {'mu_a': np.mean(a_v), 'sd_a': np.std(a_v, ddof=1),
                       'mu_d': np.mean(d_v), 'sd_d': np.std(d_v, ddof=1)}

# Binary: any chrono-stable marker (lp or ea)
a_any_m = sum(1 for r in A if r['lp_p']==1 or r['ea_p']==1)
d_any_m = sum(1 for r in D_att if r['lp_p']==1 or r['ea_p']==1)
pa_marker = (a_any_m + 0.5) / (len(A) + 1)      # Laplace-smoothed
pd_marker = (d_any_m + 0.5) / (len(D_att) + 1)

print(f"\n  Model components:")
for name in ML_RATE_NAMES:
    g = ml_gauss[name]
    print(f"    {name}: Auto μ={g['mu_a']:.3f} σ={g['sd_a']:.3f}, "
          f"Dict μ={g['mu_d']:.3f} σ={g['sd_d']:.3f}")
print(f"    any_marker: Auto={a_any_m}/{len(A)} ({pa_marker:.3f}), "
      f"Dict={d_any_m}/{len(D_att)} ({pd_marker:.3f})")

from scipy.optimize import minimize_scalar

def ml_neg_ll(pi, data):
    """Neg log-likelihood for mixture model on a set of letters."""
    if pi <= 0 or pi >= 1: return 1e10
    ll = 0
    for r in data:
        log_la = 0; log_ld = 0
        for name in ML_RATE_NAMES:
            g = ml_gauss[name]
            v = r[name]
            log_la += norm.logpdf(v, g['mu_a'], g['sd_a'])
            log_ld += norm.logpdf(v, g['mu_d'], g['sd_d'])
        has = 1 if (r['lp_p']==1 or r['ea_p']==1) else 0
        log_la += has * np.log(pa_marker) + (1-has) * np.log(1-pa_marker)
        log_ld += has * np.log(pd_marker) + (1-has) * np.log(1-pd_marker)
        log_num = np.log(pi) + log_ld
        log_den_a = np.log(1-pi) + log_la
        mx = max(log_num, log_den_a)
        log_mix = mx + np.log(np.exp(log_num - mx) + np.exp(log_den_a - mx))
        ll += log_mix
    return -ll

def ml_profile_ci(neg_ll_fn, pi_hat, data):
    ml_val = -neg_ll_fn(pi_hat, data)
    thr = ml_val - 1.92  # 95% profile CI
    lo = pi_hat; hi = pi_hat
    for pp in np.linspace(0.001, pi_hat, 500):
        if -neg_ll_fn(pp, data) >= thr: lo = pp; break
    for pp in np.linspace(pi_hat, 0.999, 500):
        if -neg_ll_fn(pp, data) < thr: hi = pp; break
    return lo, hi

def ml_posterior_dict(r, pi):
    """P(Dict|features) for a single letter."""
    log_la = 0; log_ld = 0
    for name in ML_RATE_NAMES:
        g = ml_gauss[name]
        v = r[name]
        log_la += norm.logpdf(v, g['mu_a'], g['sd_a'])
        log_ld += norm.logpdf(v, g['mu_d'], g['sd_d'])
    has = 1 if (r['lp_p']==1 or r['ea_p']==1) else 0
    log_la += has * np.log(pa_marker) + (1-has) * np.log(1-pa_marker)
    log_ld += has * np.log(pd_marker) + (1-has) * np.log(1-pd_marker)
    log_num = np.log(pi) + log_ld
    log_den_a = np.log(1-pi) + log_la
    mx = max(log_num, log_den_a)
    return np.exp(log_num - mx) / (np.exp(log_num - mx) + np.exp(log_den_a - mx))

# Fit on REST (Att only)
res_rest = minimize_scalar(ml_neg_ll, bounds=(0.01, 0.99), method='bounded', args=(R_att,))
ci_rest = ml_profile_ci(ml_neg_ll, res_rest.x, R_att)

print(f"\n  Joint ML (velim + exclamations + si_et + markers, Att REST):")
print(f"    π = {res_rest.x:.3f}  95% CI [{ci_rest[0]:.3f}, {ci_rest[1]:.3f}]")

# ── Method 2: Chrono-stable marker rate (independent) ────────────────────

auto_mr = sum(1 for r in A if r['lp_p']==1 or r['ea_p']==1) / len(A)
rest_mr = sum(1 for r in R_att if r['lp_p']==1 or r['ea_p']==1) / len(R_att)
pi_markers = 1 - (rest_mr / auto_mr) if auto_mr > 0 else np.nan

print(f"\n  Chrono-stable marker rate (lp + ea, independent):")
print(f"    Auto rate = {auto_mr:.3f}, REST(Att) rate = {rest_mr:.3f}")
print(f"    π = {pi_markers:.2f}")
print(f"    (Logic: if all Auto have rate r_A and all Dict have rate 0,")
print(f"     then REST rate = (1-π)×r_A, so π = 1 - REST/Auto)")

# ── Calibration on labelled set ───────────────────────────────────────────

print(f"\n  --- Calibration ---")

labelled = A + D_att
true_pi = len(D_att) / len(labelled)

# ML π on labelled (ignoring labels)
res_lab = minimize_scalar(ml_neg_ll, bounds=(0.01, 0.99), method='bounded', args=(labelled,))
ci_lab = ml_profile_ci(ml_neg_ll, res_lab.x, labelled)

print(f"\n  ML on labelled set (labels ignored):")
print(f"    True π = {true_pi:.3f}")
print(f"    ML π   = {res_lab.x:.3f}  95% CI [{ci_lab[0]:.3f}, {ci_lab[1]:.3f}]")

# AUC of posteriors on labelled
a_posts = np.array([ml_posterior_dict(r, res_rest.x) for r in A])
d_posts = np.array([ml_posterior_dict(r, res_rest.x) for r in D_att])
u_ml, p_ml = mannwhitneyu(d_posts, a_posts, alternative='two-sided')
auc_ml = max(u_ml / (len(d_posts) * len(a_posts)),
             1 - u_ml / (len(d_posts) * len(a_posts)))

print(f"\n  Posterior separation on labelled (using REST π = {res_rest.x:.3f}):")
print(f"    Auto mean P(Dict) = {np.mean(a_posts):.3f}, "
      f"Dict mean P(Dict) = {np.mean(d_posts):.3f}")
print(f"    AUC = {auc_ml:.3f}, MW p = {p_ml:.4f}")

# Classification
for thr in [0.3, 0.5]:
    a_ok = sum(1 for p in a_posts if p <= thr)
    d_ok = sum(1 for p in d_posts if p > thr)
    print(f"    At P(Dict)>{thr}: Auto correct {a_ok}/{len(a_posts)} ({a_ok/len(a_posts)*100:.0f}%), "
          f"Dict correct {d_ok}/{len(d_posts)} ({d_ok/len(d_posts)*100:.0f}%)")

# ── Augmentation calibration ──────────────────────────────────────────────

print(f"\n  --- Augmentation calibration ---")
print(f"  (Add marker-identified Auto letters from REST to training Auto;")
print(f"   refit ML on remaining REST to check bias stability)")

def has_any_marker(r):
    return r['fi_p']==1 or r['lp_p']==1 or r['ea_p']==1 or r['qq_adv_p']==1

def has_n_markers(r):
    return r['fi_p'] + r['lp_p'] + r['ea_p'] + r['qq_adv_p']

R_att_marked = sorted([r for r in R_att if has_any_marker(r)],
                       key=lambda r: -has_n_markers(r))
R_att_unmarked = [r for r in R_att if not has_any_marker(r)]

def fit_ml_quick(A_train, D_train, R_test):
    g = {}
    for name in ML_RATE_NAMES:
        av = np.array([r[name] for r in A_train])
        dv = np.array([r[name] for r in D_train])
        g[name] = {'mu_a': np.mean(av), 'sd_a': max(np.std(av,ddof=1),0.01),
                    'mu_d': np.mean(dv), 'sd_d': max(np.std(dv,ddof=1),0.01)}
    aa = sum(1 for r in A_train if r['lp_p']==1 or r['ea_p']==1)
    dd = sum(1 for r in D_train if r['lp_p']==1 or r['ea_p']==1)
    pa_t = (aa+0.5)/(len(A_train)+1); pd_t = (dd+0.5)/(len(D_train)+1)

    def nll(pi, data):
        if pi<=0 or pi>=1: return 1e10
        ll=0
        for r in data:
            la=0; ld=0
            for nm in ML_RATE_NAMES:
                la += norm.logpdf(r[nm], g[nm]['mu_a'], g[nm]['sd_a'])
                ld += norm.logpdf(r[nm], g[nm]['mu_d'], g[nm]['sd_d'])
            h = 1 if (r['lp_p']==1 or r['ea_p']==1) else 0
            la += h*np.log(pa_t)+(1-h)*np.log(1-pa_t)
            ld += h*np.log(pd_t)+(1-h)*np.log(1-pd_t)
            ln = np.log(pi)+ld; la2 = np.log(1-pi)+la
            mx = max(ln,la2)
            ll += mx+np.log(np.exp(ln-mx)+np.exp(la2-mx))
        return -ll

    lab = list(A_train)+list(D_train)
    rl = minimize_scalar(nll, bounds=(0.01,0.99), method='bounded', args=(lab,))
    rr = minimize_scalar(nll, bounds=(0.01,0.99), method='bounded', args=(R_test,))
    return rl.x, rr.x

print(f"\n  {'added':>6s} {'n_A':>5s} {'n_R':>5s} {'true_π':>7s} {'ML_lab':>7s} {'ML_rest':>8s} {'bias':>7s}")
print(f"  {'-'*52}")

for n_add in [0, 20, 40, 60, len(R_att_marked)]:
    to_add = R_att_marked[:n_add]
    A_aug = list(A) + to_add
    R_rem = R_att_unmarked + R_att_marked[n_add:]
    if not R_rem: continue
    ml_lab, ml_rest = fit_ml_quick(A_aug, D_att, R_rem)
    tp = len(D_att)/(len(A_aug)+len(D_att))
    print(f"  {'+'+str(n_add):>6s} {len(A_aug):>5d} {len(R_rem):>5d} {tp:>7.3f} "
          f"{ml_lab:>7.3f} {ml_rest:>8.3f} {ml_lab-tp:>+7.3f}")

# ── Summary ───────────────────────────────────────────────────────────────

cal_bias = true_pi - res_lab.x
bias_corrected = res_rest.x + cal_bias

print(f"\n  --- Summary ---")
print(f"  Joint ML (rates + markers):    π = {res_rest.x:.3f} [{ci_rest[0]:.3f}, {ci_rest[1]:.3f}]")
print(f"  Calibration bias:              {cal_bias:+.3f} (true {true_pi:.3f} − ML {res_lab.x:.3f})")
print(f"  Bias-corrected ML:             π ≈ {bias_corrected:.2f}")
print(f"  Chrono-stable markers (indep): π = {pi_markers:.2f}")
print(f"  Augmentation check: bias disappears when Auto is enlarged with")
print(f"  marker letters; remaining REST π rises as expected (Auto-like")
print(f"  letters removed). Auto rate distributions barely shift,")
print(f"  confirming marker letters are genuinely Auto-like.")
print(f"\n  Best estimate: π ≈ 0.30–0.35 (roughly one in three)")
print(f"  Plausible range: [0.25, 0.40]")

# ── Lab+ enrichment table ─────────────────────────────────────────────────

print("\n" + "="*70)
print("LAB+ ENRICHMENT TABLE (labelled + tails, illustrative)")
print("="*70)

# Compute per-letter rates for all Att letters
for r in all_letters:
    if 'nec_ratio_val' not in r:
        r['nec_ratio_val'] = r['nec_n']/(r['nec_n']+r['neque_n']) if (r['nec_n']+r['neque_n'])>0 else np.nan
        r['ac_ratio_val'] = r['ac_atque_n']/r['coord_n'] if r['coord_n']>0 else np.nan

# Get the pl_resid sorting for REST
auto_pl = np.array([r['pl_resid'] for r in A])
dict_pl = np.array([r['pl_resid'] for r in D_att])
_mu_a = np.mean(auto_pl); _sd_a = np.std(auto_pl, ddof=1)
_mu_d = np.mean(dict_pl); _sd_d = np.std(dict_pl, ddof=1)

def _post_pl(x, pi=PI_0):
    la = norm.pdf(x, _mu_a, _sd_a); ld = norm.pdf(x, _mu_d, _sd_d)
    return (ld*pi)/(ld*pi + la*(1-pi))

PA_rest = np.array([_post_pl(r['pl_resid']) for r in R_att])
rs_rest = sorted(range(len(R_att)), key=lambda i: PA_rest[i])

lab_features = [
    ('velim',     lambda g: rate_k(g,'velim_n'),  '‰'),
    ('exclamations',     lambda g: rate_k(g,'excl_n'),   '‰'),
    ('nec_ratio', nec_ratio,                       'ratio'),
    ('ac_ratio',  lit_share,                       'ratio'),
    ('si_et',     lambda g: rate_k(g,'si_et_n'),  '‰'),
]
lab_binary = [
    ('fut imp',   'fi_p'),
    ('long perf', 'lp_p'),
    ('ego autem', 'ea_p'),
    ('qq_adv',    'qq_adv_p'),
]

print(f"\n{'Feature':12s} {'unit':6s} {'Auto':>6s} {'Dict':>6s} {'p_lab':>7s}", end='')
for th in [10, 15, 20]:
    print(f'  eA_{th:d}% eD_{th:d}%', end='')
print()

for name, fn, unit in lab_features:
    va = fn(A); vd = fn(D_att)
    delta, p = boot(D_att, A, fn)
    print(f'{name:12s} {unit:6s} {va:>6.3f} {vd:>6.3f} {p:>7.3f}', end='')
    for th in [10, 15, 20]:
        n_tail = max(1, len(R_att)*th//100)
        ea_letters = A + [R_att[i] for i in rs_rest[:n_tail]]
        ed_letters = list(D_att) + [R_att[i] for i in rs_rest[-n_tail:]]
        va2 = fn(ea_letters); vd2 = fn(ed_letters)
        print(f'  {va2:>5.3f}  {vd2:>5.3f}', end='')
        if th == 15:
            _, p15 = boot(ed_letters, ea_letters, fn)
            print(f' p={fp(p15)}', end='')
    print()

for name, key in lab_binary:
    ay = sum(1 for r in A if r[key]==1)
    dy = sum(1 for r in D_att if r[key]==1)
    _, p = stats.fisher_exact([[dy,len(D_att)-dy],[ay,len(A)-ay]])
    print(f'{name:12s} {"pres%":6s} {ay/len(A)*100:>5.0f}% {dy/len(D_att)*100:>4.0f}% {p:>7.3f}', end='')
    for th in [10, 15, 20]:
        n_tail = max(1, len(R_att)*th//100)
        ea_letters = A + [R_att[i] for i in rs_rest[:n_tail]]
        ed_letters = list(D_att) + [R_att[i] for i in rs_rest[-n_tail:]]
        ay2 = sum(1 for r in ea_letters if r[key]==1)
        dy2 = sum(1 for r in ed_letters if r[key]==1)
        print(f'  {ay2/len(ea_letters)*100:>4.0f}%  {dy2/len(ed_letters)*100:>4.0f}%', end='')
        if th == 15:
            _, p15 = stats.fisher_exact([[dy2,len(ed_letters)-dy2],[ay2,len(ea_letters)-ay2]])
            print(f' p={fp(p15)}', end='')
    print()

# ── Composite ranking D ───────────────────────────────────────────────────

print("\n" + "="*70)
print("COMPOSITE RANKING D")
print("="*70)

# Build D for all Att letters using z-scored features
# Direction: positive = more Dict-like
R_att_all = [r for r in all_letters if r['corpus']=='Att']

# Compute per-letter values for all Att
for r in R_att_all:
    r['velim_rate'] = r['velim_n'] / r['tokens'] * 1000
    r['excl_rate'] = r['excl_n'] / r['tokens'] * 1000
    r['si_et_rate'] = r['si_et_n'] / r['tokens'] * 1000

D_FEATURES = [
    # (key, flip): flip=True means Auto has higher values, so negate for Dict-direction
    ('pl_resid',      True),   # Auto higher → flip
    ('sd_resid',      True),   # Auto higher → flip
    ('velim_rate',    False),  # Dict higher
    ('excl_rate',     False),  # Dict higher
    ('si_et_rate',    False),  # Dict higher
    ('nec_ratio_val', False),  # Dict higher
    ('ac_ratio_val',  True),   # Auto higher → flip
    ('fi_p',          True),   # Auto present → flip (1=Auto-like)
    ('lp_p',          True),
    ('ea_p',          True),
    ('qq_adv_p',      True),
]

# Compute z-scores on all Att letters
z_data = {}
for key, flip in D_FEATURES:
    vals = []
    for r in R_att_all:
        v = r.get(key)
        if v is not None and not (isinstance(v, float) and np.isnan(v)):
            vals.append(v)
    mu = np.mean(vals); sd = np.std(vals, ddof=1)
    if sd == 0: sd = 1
    z_data[key] = (mu, sd, flip)

for r in R_att_all:
    zscores = []
    for key, flip in D_FEATURES:
        v = r.get(key)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            continue
        mu, sd, fl = z_data[key]
        z = (v - mu) / sd
        if fl: z = -z  # flip so positive = Dict-like
        zscores.append(z)
    r['D_score'] = np.mean(zscores) if zscores else 0

# Rank: D^C = percentile (1 = most Dict-like)
all_D = sorted(R_att_all, key=lambda r: -r['D_score'])
for rank, r in enumerate(all_D, 1):
    r['D_centile'] = round(rank / len(all_D) * 100)

# AUC on full labelled
a_d = np.array([r['D_score'] for r in R_att_all if r['label']=='Auto'])
d_d = np.array([r['D_score'] for r in R_att_all if r['label']=='Dict'])
u_d, p_d = mannwhitneyu(d_d, a_d, alternative='two-sided')
auc_d = max(u_d/(len(d_d)*len(a_d)), 1-u_d/(len(d_d)*len(a_d)))

print(f"\n  D separates all labelled: AUC = {auc_d:.3f}, MW p = {p_d:.6f}")

# ── Composite correlation (z-composite vs syntax, vs chrono) ──────────────

print("\n" + "="*70)
print("COMPOSITE CORRELATION")
print("="*70)

# Composite of LEXICAL features only (no syntax in composite for this test)
LEX_FEATURES = [
    ('velim_rate', False), ('excl_rate', False), ('si_et_rate', False),
    ('nec_ratio_val', False), ('ac_ratio_val', True),
    ('fi_p', True), ('lp_p', True), ('ea_p', True), ('qq_adv_p', True),
]

R_att_only = [r for r in R_att_all if r['label']=='Rest']

for r in R_att_only:
    zscores = []
    for key, flip in LEX_FEATURES:
        v = r.get(key)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            continue
        mu, sd, fl = z_data[key]
        z = (v - mu) / sd
        if fl: z = -z
        zscores.append(z)
    r['lex_composite'] = np.mean(zscores) if zscores else 0

# Correlation with syntax
lex_arr = np.array([r['lex_composite'] for r in R_att_only])
pl_arr = np.array([r['pl_resid'] for r in R_att_only])

# We want: Dict-like syntax = lower pl_resid, Dict-like lex = positive composite
# So correlation should be negative (higher composite = lower pl_resid)
rho_syn, p_syn = spearmanr(lex_arr, pl_arr)
print(f"\n  Lexical composite × pl_resid (REST Att): ρ = {rho_syn:+.3f}, p = {p_syn:.4f}")
print(f"  (Negative = Dict-like lex predicts Dict-like syntax ✓)" if rho_syn < 0 else "")

# Correlation with chronology
dated_rest = [r for r in R_att_only if r['uid'] in dates]
lex_d = np.array([r['lex_composite'] for r in dated_rest])
yr_d = np.array([dates[r['uid']] for r in dated_rest])
rho_chr, p_chr = spearmanr(lex_d, yr_d)
print(f"  Lexical composite × year (REST Att): ρ = {rho_chr:+.3f}, p = {p_chr:.4f}")

# ── §4.2 AUCs ────────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§4.2 COMPOSITE D: LABELLED AUCs")
print("="*70)

# Full labelled (already computed above)
print(f"\n  Full labelled ({len(a_d)} Auto, {len(d_d)} Dict):")
print(f"    AUC = {auc_d:.3f}, MW p = {p_d:.6f}")

# Explicit-only (from supplementary materials)
EXPLICIT_AUTO = {'8.2', '12.32', '14.22', '15.20'}
EXPLICIT_DICT = {'2.23', '4.16', '5.17', '7.13A', '8.12', '8.13',
                 '10.3A', '14.21', '16.15'}

# Build explicit-only sets from the Att letters in our corpus
a_exp = [r for r in R_att_all if r['label']=='Auto' and r['uid'] in EXPLICIT_AUTO]
d_exp = [r for r in R_att_all if r['label']=='Dict' and r['uid'] in EXPLICIT_DICT]

if a_exp and d_exp:
    a_exp_d = np.array([r['D_score'] for r in a_exp])
    d_exp_d = np.array([r['D_score'] for r in d_exp])
    u_exp, p_exp = mannwhitneyu(d_exp_d, a_exp_d, alternative='two-sided')
    auc_exp = max(u_exp/(len(d_exp_d)*len(a_exp_d)),
                  1-u_exp/(len(d_exp_d)*len(a_exp_d)))
    print(f"\n  Explicit-only ({len(a_exp)} Auto, {len(d_exp)} Dict):")
    print(f"    AUC = {auc_exp:.3f}, MW p = {p_exp:.4f}")
    print(f"    Auto: {[r['uid'] for r in a_exp]}")
    print(f"    Dict: {[r['uid'] for r in d_exp]}")
else:
    print(f"\n  Explicit-only: insufficient data (Auto={len(a_exp)}, Dict={len(d_exp)})")

# Eye-trouble removed: drop 7.13A, 8.12, 8.13 from Dict
EYE_TROUBLE = {'7.13A', '8.12', '8.13'}
a_noeye = [r for r in R_att_all if r['label']=='Auto']
d_noeye = [r for r in R_att_all if r['label']=='Dict' and r['uid'] not in EYE_TROUBLE]
a_noeye_d = np.array([r['D_score'] for r in a_noeye])
d_noeye_d = np.array([r['D_score'] for r in d_noeye])

if len(d_noeye_d) > 1:
    u_ne, p_ne = mannwhitneyu(d_noeye_d, a_noeye_d, alternative='two-sided')
    auc_ne = max(u_ne/(len(d_noeye_d)*len(a_noeye_d)),
                 1-u_ne/(len(d_noeye_d)*len(a_noeye_d)))
    print(f"\n  Eye-trouble removed ({len(a_noeye)} Auto, {len(d_noeye)} Dict):")
    print(f"    AUC = {auc_ne:.3f}, MW p = {p_ne:.4f}")

# ── Matched pairs ─────────────────────────────────────────────────────────

print("\n" + "="*70)
print("§4.3 MATCHED PAIRS AND OUTLIERS")
print("="*70)

# Build uid->D lookup
uid_to_D = {r['uid']: r for r in R_att_all}

pairs = [
    ('10.3A', 'Dict', '10.2', 'Auto',
     'Dictated same day as 10.2 (autograph yesterday)'),
    ('5.17', 'Dict', '5.16', 'Auto',
     'Both on same journey, 51 BCE; 5.16 handwritten, 5.17 from carriage'),
]

print(f"\n  Matched pairs:")
for d_uid, d_lab, a_uid, a_lab, desc in pairs:
    dr = uid_to_D.get(d_uid)
    ar = uid_to_D.get(a_uid)
    if dr and ar:
        print(f"\n    {desc}")
        print(f"    {d_uid} [{d_lab}]: D^C = {dr['D_centile']}, D_score = {dr['D_score']:+.3f}")
        print(f"    {a_uid} [{a_lab}]: D^C = {ar['D_centile']}, D_score = {ar['D_score']:+.3f}")
        # Feature comparison
        print(f"    {'feature':12s} {d_uid:>8s} {a_uid:>8s} {'correct':>8s}")
        feat_check = [
            ('velim_rate', False), ('excl_rate', False), ('si_et_rate', False),
            ('nec_ratio_val', False), ('ac_ratio_val', True),
        ]
        n_correct = 0; n_total = 0
        for key, flip in feat_check:
            dv = dr.get(key); av = ar.get(key)
            if dv is None or av is None: continue
            if isinstance(dv, float) and np.isnan(dv): continue
            if isinstance(av, float) and np.isnan(av): continue
            if flip:
                correct = av > dv  # Auto should be higher
            else:
                correct = dv > av  # Dict should be higher
            n_total += 1
            if correct: n_correct += 1
            print(f"    {key:12s} {dv:>8.3f} {av:>8.3f} {'✓' if correct else '✗':>8s}")
        print(f"    Direction: {n_correct}/{n_total} correct")
    else:
        missing = []
        if not dr: missing.append(d_uid)
        if not ar: missing.append(a_uid)
        print(f"\n    {desc}: MISSING {missing}")

# Top Auto outliers (most Dict-like Auto letters)
print(f"\n  Auto outliers (most Dict-like):")
auto_sorted = sorted([r for r in R_att_all if r['label']=='Auto'],
                      key=lambda r: -r['D_score'])
for r in auto_sorted[:5]:
    print(f"    {r['uid']:8s}: D^C = {r['D_centile']}")

# Top Dict outliers (most Auto-like Dict letters)
print(f"\n  Dict outliers (most Auto-like):")
dict_sorted = sorted([r for r in R_att_all if r['label']=='Dict'],
                      key=lambda r: r['D_score'])
for r in dict_sorted[:5]:
    print(f"    {r['uid']:8s}: D^C = {r['D_centile']}")

# Highest-scoring REST letter
print(f"\n  Most Dict-like REST letters:")
rest_sorted = sorted([r for r in R_att_all if r['label']=='Rest'],
                      key=lambda r: -r['D_score'])
for r in rest_sorted[:5]:
    print(f"    {r['uid']:8s}: D^C = {r['D_centile']}")

# 5.12 (mentioned in paper as low-scoring Dict)
r_512 = uid_to_D.get('5.12')
if r_512:
    print(f"\n  5.12 (Dict, 'plane in medio mari'): D^C = {r_512['D_centile']}")

# Letters mentioned in paper
for uid in ['1.10', '2.17', '2.22', '7.19']:
    r = uid_to_D.get(uid)
    if r:
        print(f"  {uid:8s} [{r['label']}]: D^C = {r['D_centile']}")

# ── Export D^C scores to CSV ──────────────────────────────────────────────

dc_path = DATA_DIR / 'letter_d_scores.csv'
with open(dc_path, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['uid', 'label', 'tokens', 'D_score', 'D_centile',
                      'pl_resid', 'sd_resid', 'velim_rate', 'excl_rate',
                      'si_et_rate', 'nec_ratio', 'ac_ratio',
                      'fi_p', 'lp_p', 'ea_p', 'qq_adv_p'])
    for r in sorted(R_att_all, key=lambda x: -x['D_score']):
        writer.writerow([
            r['uid'], r['label'], r['tokens'],
            f"{r['D_score']:.4f}", r['D_centile'],
            f"{r['pl_resid']:.6f}", f"{r.get('sd_resid',0):.6f}",
            f"{r.get('velim_rate',0):.3f}", f"{r.get('excl_rate',0):.3f}",
            f"{r.get('si_et_rate',0):.3f}",
            f"{r.get('nec_ratio_val','')}", f"{r.get('ac_ratio_val','')}",
            r.get('fi_p',0), r.get('lp_p',0), r.get('ea_p',0), r.get('qq_adv_p',0),
        ])
print(f"\n  D^C scores exported to {dc_path} ({len(R_att_all)} letters)")

# ── §7: Corrected tails ──────────────────────────────────────────────────

print("\n" + "="*70)
print("§7. CORRECTED TAILS (pl_resid sorting)")
print("="*70)

thresholds = [5, 10, 15, 20, 25]
print(f"\n{'Feature':12s}", end='')
for th in thresholds: print(f'  {th:>7d}%', end='')
print()

# Compute all tails
tails = {}
for th in thresholds:
    lam, ed, ea, _ = get_tails(R_att, 'pl_resid', th)
    tails[th] = (lam, ed, ea)

print(f'{"λ":12s}', end='')
for th in thresholds: print(f'  {tails[th][0]:>7.3f}', end='')
print()
print(f'{"n per tail":12s}', end='')
for th in thresholds: print(f'  {len(tails[th][1]):>7d}', end='')
print('\n')

for name, fn, exp in CONT:
    print(f'{name:12s}', end='')
    for th in thresholds:
        lam,ed,ea=tails[th]
        d,p=cboot(ed,ea,fn,lam,seed=SEED+th)
        if d is None: print(f'  {"---":>7s}', end='')
        elif not dir_c(d,exp): print(f'  {"✗":>7s}', end='')
        else: print(f'  {fp(p):>7s}', end='')
    print()

for name, key, exp in BIN:
    print(f'{name:12s}', end='')
    for th in thresholds:
        _,ed,ea=tails[th]
        dy=sum(1 for r in ed if r[key]==1); ay=sum(1 for r in ea if r[key]==1)
        _2,p=stats.fisher_exact([[dy,len(ed)-dy],[ay,len(ea)-ay]])
        ra=ay/len(ea); rd=dy/len(ed)
        if not dir_b(ra,rd,exp): print(f'  {"✗":>7s}', end='')
        else: print(f'  {fp(p):>7s}', end='')
    print()

print()
print(f'{"Direction":12s}', end='')
for th in thresholds:
    lam,ed,ea=tails[th]
    res=test_features(ed,ea,lam,seed=SEED+th)
    nc=sum(1 for _,_,ok,_ in res if ok)
    print(f'  {nc:>2d}/{len(res):<2d}   ', end='')
print()

# ── §8: BH on doughnut ───────────────────────────────────────────────────

print("\n" + "="*70)
print("§8. BH CORRECTION (doughnut, pl_resid)")
print("="*70)

for th in [10, 15, 20]:
    lam, dd, da, _ = get_doughnut(R_att, 'pl_resid', th)
    if len(da)<3 or len(dd)<3: continue
    pvals=[]; names=[]
    res = test_features(dd, da, lam, seed=SEED+th)
    for name,val,ok,p in res:
        pvals.append(p if ok else 1.0)
        names.append(name)
    # Add features dropped at screening (not pre-screening chrono exclusions) at p=1.0
    for dn in ['ego_nom','qq_share']:
        pvals.append(1.0); names.append(dn)
    n=len(pvals)
    indexed=sorted(enumerate(pvals),key=lambda x:x[1])
    max_k=0
    for rank,(i,p) in enumerate(indexed,1):
        if p<=0.05*rank/n: max_k=rank
    surv=[names[i] for rank,(i,p) in enumerate(indexed,1) if rank<=max_k and i<len(names)]
    print(f"  Doughnut {th}% (λ={lam:.3f}, n={n}): {len(surv)} survivors: "
          f"{', '.join(surv) if surv else 'none'}")

# ── §9: Robustness (sd_resid) ───────────────────────────────────────────

print("\n" + "="*70)
print("§9. ROBUSTNESS: sd_resid SORTING")
print("="*70)

# Only Att letters have sd_resid from scores
R_att_sd = R_att  # sd_resid only reliable for Att

print(f"\n  REST pool for sd_resid: {len(R_att_sd)} (Att only)")

print(f"\n  Corrected tails (sd_resid):")
print(f"  {'Feature':12s}", end='')
for th in [10, 15, 20, 25]: print(f'  {th:>7d}%', end='')
print()

sd_tails = {}
for th in [10, 15, 20, 25]:
    lam, ed, ea, _ = get_tails(R_att_sd, 'sd_resid', th)
    sd_tails[th] = (lam, ed, ea)

print(f'  {"λ":12s}', end='')
for th in [10,15,20,25]: print(f'  {sd_tails[th][0]:>7.3f}', end='')
print()
print(f'  {"n per tail":12s}', end='')
for th in [10,15,20,25]: print(f'  {len(sd_tails[th][1]):>7d}', end='')
print('\n')

for name, fn, exp in CONT:
    print(f'  {name:12s}', end='')
    for th in [10,15,20,25]:
        lam,ed,ea=sd_tails[th]
        d,p=cboot(ed,ea,fn,lam,seed=SEED+th+100)
        if d is None: print(f'  {"---":>7s}', end='')
        elif not dir_c(d,exp): print(f'  {"✗":>7s}', end='')
        else: print(f'  {fp(p):>7s}', end='')
    print()

for name, key, exp in BIN:
    print(f'  {name:12s}', end='')
    for th in [10,15,20,25]:
        _,ed,ea=sd_tails[th]
        dy=sum(1 for r in ed if r[key]==1); ay=sum(1 for r in ea if r[key]==1)
        _2,p=stats.fisher_exact([[dy,len(ed)-dy],[ay,len(ea)-ay]])
        ra=ay/len(ea); rd=dy/len(ed)
        if not dir_b(ra,rd,exp): print(f'  {"✗":>7s}', end='')
        else: print(f'  {fp(p):>7s}', end='')
    print()

print()
print(f'  {"Direction":12s}', end='')
for th in [10,15,20,25]:
    lam,ed,ea=sd_tails[th]
    res=test_features(ed,ea,lam,seed=SEED+th+100)
    nc=sum(1 for _,_,ok,_ in res if ok)
    print(f'  {nc:>2d}/{len(res):<2d}   ', end='')
print()

# Doughnut on sd
print(f"\n  Doughnut (sd_resid):")
for th in [10, 15, 20, 25]:
    lam, dd, da, _ = get_doughnut(R_att_sd, 'sd_resid', th)
    if len(da)<3 or len(dd)<3: continue
    res = test_features(dd, da, lam, seed=SEED+th+100)
    nc=sum(1 for _,_,ok,_ in res if ok)
    nt=len(res)
    bp=1-stats.binom.cdf(nc-1,nt,0.5)
    wrong=[n for n,_,ok,_ in res if not ok]
    print(f"    {th}%: nA={len(da):3d}  nD={len(dd):3d}  Dir={nc}/{nt}  p={bp:.4f}  "
          f"wrong: {', '.join(wrong) if wrong else 'none'}")

# Jaccard overlap between pl and sd tails
print(f"\n  Jaccard overlap (pl vs sd tails, Att REST):")
_, _, _, rs_pl2 = get_tails(R_att_sd, 'pl_resid', 10)
_, _, _, rs_sd2 = get_tails(R_att_sd, 'sd_resid', 10)
n10 = max(1, len(R_att_sd)*10//100)
pl_d_set = set(rs_pl2[-n10:]); sd_d_set = set(rs_sd2[-n10:])
pl_a_set = set(rs_pl2[:n10]); sd_a_set = set(rs_sd2[:n10])
jd = len(pl_d_set & sd_d_set) / len(pl_d_set | sd_d_set)
ja = len(pl_a_set & sd_a_set) / len(pl_a_set | sd_a_set)
print(f"    10% Dict-leaning: Jaccard = {jd:.2f}")
print(f"    10% Auto-leaning: Jaccard = {ja:.2f}")

# ── Chrono ────────────────────────────────────────────────────────────────

print("\n" + "="*70)
print("CHRONOLOGICAL CORRELATIONS (REST, Att)")
print("="*70)

rest_dated = [r for r in R_att if dates.get(r['uid']) is not None]
for r in rest_dated: r['year'] = dates[r['uid']]
years = np.array([r['year'] for r in rest_dated])

for name, fn, _ in CONT:
    vals = [fn([r]) for r in rest_dated]
    valid = [(y,v) for y,v in zip(years,vals) if v is not None and not(isinstance(v,float) and np.isnan(v))]
    if len(valid)>10:
        ya,va=zip(*valid); rho,p=spearmanr(ya,va)
        print(f"  {name:12s} × year: ρ={rho:+.3f}, p={p:.4f}")

for name, key, _ in BIN:
    vals=[r[key] for r in rest_dated]
    rho,p=spearmanr(years[:len(vals)],vals)
    print(f"  {name:12s} × year: ρ={rho:+.3f}, p={p:.4f}")

pl_arr=np.array([r['pl_resid'] for r in rest_dated])
rho,p=spearmanr(years,pl_arr)
print(f"  {'pl_resid':12s} × year: ρ={rho:+.3f}, p={p:.4f}")

print("\n" + "="*70)
print("PIPELINE COMPLETE")
print("="*70)
